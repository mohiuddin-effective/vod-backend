# Effective Education Hub — API

> **v2.0 update:** this repo now includes a real Postgres-backed database,
> login (JWT), and a full Admin API (overview stats, course/teacher
> approval, payouts, reports) — replacing the hardcoded numbers that were
> previously only in the frontend HTML. See **"v2.0 — Database + Admin API"**
> below for setup. The original VOD access-control API (section below) is
> unchanged and still works the same way.

## v2.0 — Database + Admin API

### 1. Create a Postgres database on Render
Render Dashboard → **New +** → **PostgreSQL** → pick the free plan → create.
Once it's up, copy the **Internal Database URL** shown on its page.

### 2. Set environment variables on this service
On this web service's **Environment** tab, add (see `.env.example` for the full list):
- `DATABASE_URL` — the Internal Database URL from step 1
- `JWT_SECRET` — generate with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
- `CORS_ORIGINS` — `https://effectiveeducationhub.com,https://effectiveeduhub.com`
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — used once by the seed script, then you can remove `ADMIN_PASSWORD`

### 3. Create the tables and the first admin login
Render doesn't give you a shell on the free plan by default, so run these
**from your own computer** with `DATABASE_URL` pointed at Render's
**External Database URL** (shown on the same Postgres page):
```bash
git clone https://github.com/mohiuddin-effective/vod-backend.git
cd vod-backend
npm install
DATABASE_URL="<external-url-from-render>" JWT_SECRET=x ADMIN_EMAIL=admin@effectiveeducationhub.com ADMIN_PASSWORD="<pick-a-strong-password>" npm run migrate
DATABASE_URL="<external-url-from-render>" ADMIN_PASSWORD="<same-password>" npm run seed
```
`migrate` creates the tables (`users`, `courses`, `enrollments`, `orders`, `payouts`, `activity_log`).
`seed` creates your admin login plus a few sample teachers/courses/payouts so the dashboard isn't empty.

### 4. Log in
```
POST /auth/login
{ "email": "admin@effectiveeducationhub.com", "password": "<your password>" }
```
Returns a `token` — send it as `Authorization: Bearer <token>` on every `/admin/*` request.

### 5. New endpoints
| Method & path | What it replaces in the frontend mock |
|---|---|
| `GET /admin/overview` | The 4 metric cards + "সাম্প্রতিক কার্যক্রম" feed |
| `GET /admin/courses/pending` | The AI অ্যাপ্রুভাল table |
| `POST /admin/courses/:id/approve` `.../reject` | The ✅ অ্যাপ্রুভ button |
| `GET /admin/teachers/pending` | Teacher verification queue |
| `POST /admin/teachers/:id/verify` | Teacher verify action |
| `GET /admin/payouts` | The পেআউট table |
| `POST /admin/payouts/:id/pay` `.../pay-all` | The পেআউট buttons |
| `GET /admin/report` | The রিপোর্ট tab breakdown |

All of the above, plus the existing `/admin/videos/*` VOD routes, now require
`Authorization: Bearer <token>` from an admin login — they were previously
open to anyone who knew the URL.

### 6. Teacher / Publisher / Seller dashboards (v2.1)
Same pattern as Admin: log in via `/auth/login`, get a JWT, send it as
`Authorization: Bearer <token>`. Each role only ever sees its own data.

| Role | Endpoints | Backed by |
|---|---|---|
| Teacher | `GET /teacher/overview`, `GET /teacher/courses`, `POST /teacher/courses` | `courses` table, filtered by `teacher_id` |
| Publisher | `GET /publisher/overview`, `GET /publisher/products`, `POST /publisher/products`, `PUT /publisher/products/:id` | `products` table, `type='book'`, filtered by `owner_id` |
| Seller | same shape as Publisher, mounted at `/seller/*` | `products` table, `type='mart'` |

Seed data includes one sample login per role (see `db/seed.js`):
`farhana@example.com` (teacher), `publisher@example.com`, `seller@example.com`
— all with password `ChangeMe123!`. **Change these before going live** —
either update the passwords via your own `PUT` route later, or delete/re-seed.

The corresponding sections of `index.html` (Dashboard → Teacher / Publisher /
Seller) now have their own login gates and pull live data from these
endpoints, the same way the Admin dashboard does.

### What's still missing (real, but out of scope for this pass)
- **Course submission / enrollment / order-creation endpoints** — right now
  rows only get into `courses`/`orders`/`enrollments` via `npm run seed` or
  direct SQL. The public-facing "submit a course", "buy a book", "enroll"
  flows need their own routes before the numbers move on their own.
- **Student dashboard** — Admin, Teacher, Publisher, and Seller are all
  wired to live data now; Student is the one role left on static mock HTML.
- **Registration UI** — `POST /auth/register` exists and works, but nothing
  in `index.html` calls it yet (teachers/publishers/sellers currently only
  get in via `db/seed.js` or direct SQL).

---

# Effective EduHub — Recorded Class Access Control API

Implements exactly the endpoints from the design doc. Tested locally — all endpoints confirmed working (lock/unlock, tier-based access checks, promo scheduling).

## Run locally
```
npm install
npm start
```
Server starts on `http://localhost:4000` (or `$PORT`).

## Deploy (pick one — all have free tiers)
- **Railway / Render**: connect this folder as a repo, it auto-detects `npm start`. Set `PORT` env var if required by the platform (most auto-inject it).
- **A VPS you already have**: `pm2 start server.js` behind Nginx, or just `node server.js` in a systemd service.

## Connect the frontend
In `effective-v14.html`, near the top of the main `<script>` block (or in a small inline `<script>` right before it), set:
```html
<script>window.VOD_API_BASE = 'https://your-deployed-api-url.com';</script>
```
Once this is set, the admin lock/unlock buttons and promo scheduler in the SPA will call the real API automatically. Until you set it, the SPA keeps working in local demo mode (no errors, just no persistence across page reloads).

## What's real vs. what's still a stub
| Piece | Status |
|---|---|
| Lock/unlock, access-rule, schedule-promo endpoints | ✅ Real, tested |
| `canAccess()` tier logic (public/batch/paid/promo) | ✅ Real, tested |
| Data storage | ⚠️ In-memory — resets on server restart. Swap for Postgres using the schema in the design doc when ready (the function signatures won't need to change) |
| `playback-url` signed URL | ⚠️ Returns a placeholder URL shaped like the real thing. Replace with actual Cloudflare Stream / Mux signed-URL generation once you pick a video host |
| Push/SMS/WhatsApp/Email dispatch on promo schedule | ⚠️ Logs the job (`console.log`), doesn't actually send anything yet. Wire in Firebase Admin SDK / SSL Wireless / WhatsApp Business Cloud API / SES where marked `TODO` in `server.js` |
| Auth (identifying which user is asking) | ⚠️ Demo accepts `user_id`/`batch_id` as query params for testing. Replace with your real session/JWT middleware before going live — right now anyone could pass any `batch_id` |

## Next security step before real deployment
The demo `playback-url` endpoint trusts `batch_id` from the query string, which isn't safe for production — swap it for your real auth middleware so `req.user` comes from a verified session/token, not a client-supplied parameter.
