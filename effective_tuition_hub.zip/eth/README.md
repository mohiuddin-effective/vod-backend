# Effective Tuition Hub — tutor & tuition matching app
A wing of Effective Education Hub. Flutter app · Node.js/Express API · PostgreSQL + PostGIS.

```
database/schema.sql        PostGIS schema, generated monthly-equivalent budget columns, indexes
backend/                   Express 5 API (zod validation, JWT, pg)
flutter_app/lib/           Screens, widgets, API + Google Places services
```

## 1. Database
```bash
createdb effective_tuition_hub
psql effective_tuition_hub -f database/schema.sql   # needs PostGIS installed
```

## 2. Backend
```bash
cd backend && cp .env.example .env   # set DATABASE_URL and JWT_SECRET
npm install && npm run dev           # http://localhost:4000
```

| Method | Endpoint | Who | Notes |
|---|---|---|---|
| POST | /api/auth/register, /api/auth/login | all | roles: tutor, guardian, student |
| POST | /api/tuition-posts | guardian/student | exact lat/lng + budget/days/hours |
| GET  | /api/tuition-posts | public | search (used by tutors) |
| GET  | /api/tuition-posts/mine | guardian/student | exact location + applications count |
| POST | /api/tuition-posts/:id/apply | tutor | |
| PATCH| /api/tuition-posts/:id/status | owner | active / filled / cancelled |
| POST | /api/tutor-posts | tutor | post + up to 5 teaching areas (lat/lng/radius) |
| GET  | /api/tutor-posts | public | search (used by guardians) |
| GET  | /api/tutor-posts/mine, PATCH /:id/status | tutor | |

**Search query params (both GET endpoints):**
`q, subject=Physics,ICT, class_level=Class 9,Class 10, lat, lng, radius_km (0.5–50, default 5),
budget_min, budget_max (monthly-equivalent ৳), rate_type, days_min, days_max, hours_min, hours_max,
gender, sort=newest|distance|budget_low|budget_high, page, limit`

Example: `GET /api/tuition-posts?lat=22.3569&lng=91.7832&radius_km=5&subject=Physics&budget_min=3000&budget_max=8000&days_min=2&days_max=4&sort=distance`

**How matching works**
- Tuition search: post pin within `radius_km` of the searched point (`ST_DWithin`, GiST index).
- Tutor search: a tutor matches when any of their teaching-area radii covers the searched point (i.e. they will travel there).
- Budget: hourly/weekly/monthly rates are stored with a generated monthly equivalent (≈4.33 weeks/month); the filter checks that ranges overlap.
- Days/hours: guardian posts hold one value, tutor posts hold a willing range; filters use range overlap for tutors.
- Privacy: public responses round coordinates to ~110 m and omit the full address; only the owner sees the exact pin.

## 3. Flutter app
```bash
cd flutter_app
flutter create .          # generates android/ ios/ (keeps lib/ and pubspec.yaml)
flutter pub get
flutter run --dart-define=API_BASE=http://10.0.2.2:4000/api --dart-define=GOOGLE_MAPS_KEY=YOUR_KEY
```
Google Cloud: enable **Maps SDK for Android/iOS**, **Places API (New)**, **Geocoding API**; restrict the key.

Android — `android/app/src/main/AndroidManifest.xml` (inside `<application>`, plus permissions):
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<meta-data android:name="com.google.android.geo.API_KEY" android:value="YOUR_KEY"/>
```
iOS — `Info.plist`: add `NSLocationWhenInUseUsageDescription`; in `AppDelegate.swift` call `GMSServices.provideAPIKey("YOUR_KEY")`.

Screens: `search_screen` (tuition/tutor toggle, live search, chips, pagination) · `filter_sheet` (subject, class, map location + radius, budget, days, duration, sort) · `post_requirement_screen` (guardian) · `post_availability_screen` (tutor, multiple areas with radius) · `location_picker_screen` (Places autocomplete + draggable map pin).

## Not included yet
Login/register screens (set `ApiService.token`), chat/contact flow, push notifications, phone OTP, admin verification.
