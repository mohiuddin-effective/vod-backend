import 'dotenv/config';
import pg from 'pg';

// Return BIGINT and NUMERIC as JS numbers (instead of strings) so the app gets clean JSON.
pg.types.setTypeParser(20, (v) => parseInt(v, 10));
pg.types.setTypeParser(1700, (v) => parseFloat(v));

export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
export const query = (text, params) => pool.query(text, params);
