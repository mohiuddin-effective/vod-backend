import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { searchSchema, makeParams, likePattern, pointSql, meta, stripTotal } from '../utils/search.js';

const r = Router();

const createSchema = z.object({
  title: z.string().trim().min(5).max(200),
  description: z.string().trim().max(2000).nullish(),
  subjects: z.array(z.string().trim().min(1).max(60)).min(1).max(8),
  class_level: z.string().trim().min(1).max(50),
  medium: z.string().trim().max(50).default('Bangla Medium'),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  place_id: z.string().max(300).nullish(),
  formatted_address: z.string().max(500).nullish(),
  area_name: z.string().max(120).nullish(),
  days_per_week: z.number().int().min(1).max(7),
  hours_per_session: z.number().min(0.5).max(12),
  preferred_time: z.string().max(30).nullish(),
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullish(),
  rate_type: z.enum(['hourly', 'weekly', 'monthly']),
  budget_min: z.number().min(0),
  budget_max: z.number().min(0),
  preferred_gender: z.enum(['male', 'female', 'any']).default('any'),
}).refine((d) => d.budget_max >= d.budget_min, { message: 'budget_max must be >= budget_min', path: ['budget_max'] });

// ── Create a tuition requirement (guardian / student) ──
r.post('/', requireAuth, requireRole('guardian', 'student'), async (req, res) => {
  const d = createSchema.parse(req.body);
  const { rows } = await query(
    `INSERT INTO tuition_posts
       (guardian_id, title, description, subjects, class_level, medium, location,
        place_id, formatted_address, area_name, days_per_week, hours_per_session,
        preferred_time, start_date, rate_type, budget_min, budget_max, preferred_gender)
     VALUES ($1,$2,$3,$4,$5,$6, ST_SetSRID(ST_MakePoint($7::float8,$8::float8),4326)::geography,
             $9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
     RETURNING id, status, expires_at, monthly_min, monthly_max`,
    [req.user.id, d.title, d.description ?? null, d.subjects, d.class_level, d.medium, d.lng, d.lat,
     d.place_id ?? null, d.formatted_address ?? null, d.area_name ?? null, d.days_per_week,
     d.hours_per_session, d.preferred_time ?? null, d.start_date ?? null, d.rate_type,
     d.budget_min, d.budget_max, d.preferred_gender]);
  res.status(201).json(rows[0]);
});

// ── Search tuitions (public; used by tutors) ──
const ORDER = {
  newest: 'p.created_at DESC',
  distance: 'distance_km ASC, p.created_at DESC',
  budget_low: 'p.monthly_min ASC, p.created_at DESC',
  budget_high: 'p.monthly_max DESC, p.created_at DESC',
};

r.get('/', async (req, res) => {
  const f = searchSchema.parse(req.query);
  const P = makeParams();
  const hasGeo = f.lat !== undefined;
  const pt = hasGeo ? pointSql(P, f.lat, f.lng) : null;
  const where = [`p.status = 'active'`, `p.expires_at > now()`];

  if (hasGeo) where.push(`ST_DWithin(p.location, ${pt}, ${P.add(f.radius_km * 1000)}::float8)`);
  if (f.subject) where.push(`p.subjects && ${P.add(f.subject)}::text[]`);
  if (f.class_level) where.push(`p.class_level = ANY(${P.add(f.class_level)}::text[])`);
  if (f.rate_type) where.push(`p.rate_type = ${P.add(f.rate_type)}::rate_type`);
  if (f.q) {
    const k = P.add(likePattern(f.q));
    where.push(`(p.title ILIKE ${k} OR p.area_name ILIKE ${k}
                 OR EXISTS (SELECT 1 FROM unnest(p.subjects) s WHERE s ILIKE ${k}))`);
  }
  // Budget: ranges overlap (post's monthly range vs. the user's range)
  if (f.budget_min !== undefined) where.push(`p.monthly_max >= ${P.add(f.budget_min)}::numeric`);
  if (f.budget_max !== undefined) where.push(`p.monthly_min <= ${P.add(f.budget_max)}::numeric`);
  if (f.days_min !== undefined) where.push(`p.days_per_week >= ${P.add(f.days_min)}::int`);
  if (f.days_max !== undefined) where.push(`p.days_per_week <= ${P.add(f.days_max)}::int`);
  if (f.hours_min !== undefined) where.push(`p.hours_per_session >= ${P.add(f.hours_min)}::numeric`);
  if (f.hours_max !== undefined) where.push(`p.hours_per_session <= ${P.add(f.hours_max)}::numeric`);
  // gender = the tutor's own gender: only show posts that accept it
  if (f.gender && f.gender !== 'any') where.push(`p.preferred_gender IN ('any', ${P.add(f.gender)}::gender_pref)`);

  const sort = f.sort === 'distance' && !hasGeo ? 'newest' : f.sort;
  const limit = P.add(f.limit);
  const offset = P.add((f.page - 1) * f.limit);

  const { rows } = await query(
    `SELECT p.id, p.title, p.subjects, p.class_level, p.medium, p.area_name,
            -- public coordinates are rounded (~110 m) to protect the guardian's home
            ROUND(ST_Y(p.location::geometry)::numeric, 3) AS lat,
            ROUND(ST_X(p.location::geometry)::numeric, 3) AS lng,
            p.days_per_week, p.hours_per_session, p.preferred_time,
            p.rate_type, p.budget_min, p.budget_max, p.monthly_min, p.monthly_max,
            p.preferred_gender, p.created_at
            ${hasGeo ? `, ST_Distance(p.location, ${pt}) / 1000 AS distance_km` : ''},
            COUNT(*) OVER() AS total
       FROM tuition_posts p
      WHERE ${where.join(' AND ')}
      ORDER BY ${ORDER[sort]}
      LIMIT ${limit} OFFSET ${offset}`,
    P.values);

  res.json({ data: stripTotal(rows), meta: meta(rows, f) });
});

// ── My posts (owner sees exact location + address) ──
r.get('/mine', requireAuth, requireRole('guardian', 'student'), async (req, res) => {
  const { rows } = await query(
    `SELECT p.*, ST_Y(p.location::geometry) AS lat, ST_X(p.location::geometry) AS lng,
            (SELECT COUNT(*)::int FROM tuition_applications a WHERE a.post_id = p.id) AS applications
       FROM tuition_posts p WHERE p.guardian_id = $1 ORDER BY p.created_at DESC`, [req.user.id]);
  res.json({ data: rows.map(({ location, ...rest }) => rest) });
});

r.get('/:id', async (req, res) => {
  const { rows: [p] } = await query(
    `SELECT p.id, p.title, p.description, p.subjects, p.class_level, p.medium, p.area_name,
            ROUND(ST_Y(p.location::geometry)::numeric, 3) AS lat,
            ROUND(ST_X(p.location::geometry)::numeric, 3) AS lng,
            p.days_per_week, p.hours_per_session, p.preferred_time, p.start_date,
            p.rate_type, p.budget_min, p.budget_max, p.monthly_min, p.monthly_max,
            p.preferred_gender, p.status, p.created_at
       FROM tuition_posts p WHERE p.id = $1`, [req.params.id]);
  if (!p) return res.status(404).json({ error: 'Post not found' });
  res.json(p);
});

r.patch('/:id/status', requireAuth, requireRole('guardian', 'student'), async (req, res) => {
  const { status } = z.object({ status: z.enum(['active', 'filled', 'cancelled']) }).parse(req.body);
  const { rowCount } = await query(
    'UPDATE tuition_posts SET status = $1 WHERE id = $2 AND guardian_id = $3',
    [status, req.params.id, req.user.id]);
  if (!rowCount) return res.status(404).json({ error: 'Post not found' });
  res.json({ ok: true });
});

// ── Tutor applies to a tuition post ──
r.post('/:id/apply', requireAuth, requireRole('tutor'), async (req, res) => {
  const { cover_note } = z.object({ cover_note: z.string().max(1000).optional() }).parse(req.body ?? {});
  const { rowCount } = await query(
    `INSERT INTO tuition_applications (post_id, tutor_id, cover_note)
     SELECT p.id, $2, $3 FROM tuition_posts p WHERE p.id = $1 AND p.status = 'active'
     ON CONFLICT (post_id, tutor_id) DO NOTHING`,
    [req.params.id, req.user.id, cover_note ?? null]);
  if (!rowCount) return res.status(409).json({ error: 'Already applied, or the post is no longer active' });
  res.status(201).json({ ok: true });
});

export default r;
