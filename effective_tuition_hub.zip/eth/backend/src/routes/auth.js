import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../db.js';

const r = Router();
const sign = (u) => jwt.sign({ id: u.id, role: u.role }, process.env.JWT_SECRET, { expiresIn: '30d' });

r.post('/register', async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(2).max(100),
    email: z.string().email().toLowerCase(),
    phone: z.string().trim().min(7).max(20),
    password: z.string().min(8).max(100),
    role: z.enum(['tutor', 'guardian', 'student']),
    gender: z.enum(['male', 'female', 'other']).optional(),
  }).parse(req.body);

  const hash = await bcrypt.hash(d.password, 12);
  const { rows: [u] } = await query(
    `INSERT INTO users (name, email, phone, password_hash, role, gender)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, name, email, role`,
    [d.name, d.email, d.phone, hash, d.role, d.gender ?? null]);
  if (u.role === 'tutor') await query('INSERT INTO tutor_profiles (user_id) VALUES ($1)', [u.id]);
  res.status(201).json({ token: sign(u), user: u });
});

r.post('/login', async (req, res) => {
  const d = z.object({ email: z.string().email().toLowerCase(), password: z.string().min(1) }).parse(req.body);
  const { rows: [u] } = await query(
    'SELECT id, name, email, role, password_hash FROM users WHERE email = $1', [d.email]);
  if (!u || !(await bcrypt.compare(d.password, u.password_hash)))
    return res.status(401).json({ error: 'Invalid email or password' });
  const { password_hash, ...user } = u;
  res.json({ token: sign(user), user });
});

export default r;
