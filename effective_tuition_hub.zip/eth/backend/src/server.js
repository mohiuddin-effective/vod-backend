import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { ZodError } from 'zod';
import authRoutes from './routes/auth.js';
import tuitionRoutes from './routes/tuitionPosts.js';
import tutorRoutes from './routes/tutorPosts.js';

if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not set');

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 50 }), authRoutes);
app.use('/api/tuition-posts', rateLimit({ windowMs: 60 * 1000, limit: 120 }), tuitionRoutes);
app.use('/api/tutor-posts', rateLimit({ windowMs: 60 * 1000, limit: 120 }), tutorRoutes);

app.use((_req, res) => res.status(404).json({ error: 'Not found' }));

// Express 5 forwards rejected async handlers here automatically
app.use((err, _req, res, _next) => {
  if (err instanceof ZodError) {
    return res.status(400).json({
      error: err.issues.map((i) => `${i.path.join('.') || 'body'}: ${i.message}`).join('; '),
      details: err.issues,
    });
  }
  if (err.code === '23505') return res.status(409).json({ error: 'Email or phone already registered' });
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`API listening on :${port}`));
