import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config.dart';
import '../models/models.dart';

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, this.status);
  @override
  String toString() => message;
}

class ApiService {
  /// Set after login/register (store securely, e.g. flutter_secure_storage, in production).
  static String? token;

  static Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  static Map<String, dynamic> _parse(http.Response r) {
    final body = r.body.isEmpty ? <String, dynamic>{} : jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode >= 400) {
      throw ApiException(body['error']?.toString() ?? 'Request failed (${r.statusCode})', r.statusCode);
    }
    return body;
  }

  static Future<Map<String, dynamic>> _get(String path, Map<String, String> q) async =>
      _parse(await http.get(
        Uri.parse('${AppConfig.apiBase}$path').replace(queryParameters: q),
        headers: _headers,
      ));

  static Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async =>
      _parse(await http.post(
        Uri.parse('${AppConfig.apiBase}$path'),
        headers: _headers,
        body: jsonEncode(body),
      ));

  // Auth
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final r = await _post('/auth/login', {'email': email, 'password': password});
    token = r['token'] as String?;
    return r;
  }

  // Search (response: { data: [...], meta: { page, limit, total } })
  static Future<Map<String, dynamic>> searchTuitions(SearchFilters f, {int page = 1}) =>
      _get('/tuition-posts', {...f.toQuery(), 'page': '$page'});

  static Future<Map<String, dynamic>> searchTutors(SearchFilters f, {int page = 1}) =>
      _get('/tutor-posts', {...f.toQuery(), 'page': '$page'});

  // Posting
  static Future<Map<String, dynamic>> createTuitionPost(Map<String, dynamic> body) =>
      _post('/tuition-posts', body);

  static Future<Map<String, dynamic>> createTutorPost(Map<String, dynamic> body) =>
      _post('/tutor-posts', body);

  static Future<void> applyToTuition(int postId, {String? note}) async {
    await _post('/tuition-posts/$postId/apply', {if (note != null) 'cover_note': note});
  }
}
