import 'dart:async';
import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../widgets/filter_sheet.dart';
import '../widgets/result_cards.dart';

/// Real-time search: tuition posts (for tutors) or tutors (for guardians).
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  int _mode = 0; // 0 = tuitions, 1 = tutors
  SearchFilters _filters = SearchFilters();
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  final List<Map<String, dynamic>> _items = [];
  int _page = 1, _total = 0, _requestId = 0;
  bool _loading = false, _hasMore = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300 &&
          !_loading && _hasMore && _error == null) {
        _load();
      }
    });
    _load(reset: true);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load({bool reset = false}) async {
    final id = ++_requestId; // ignore stale responses when filters change quickly
    if (reset) {
      _page = 1;
      _hasMore = true;
    }
    setState(() {
      _loading = true;
      _error = null;
      if (reset) _items.clear();
    });
    try {
      final res = _mode == 0
          ? await ApiService.searchTuitions(_filters, page: _page)
          : await ApiService.searchTutors(_filters, page: _page);
      if (id != _requestId || !mounted) return;
      final data = (res['data'] as List).cast<Map<String, dynamic>>();
      final total = (res['meta']['total'] as num).toInt();
      setState(() {
        _items.addAll(data);
        _total = total;
        _hasMore = _items.length < total && data.isNotEmpty;
        _page++;
        _loading = false;
      });
    } catch (e) {
      if (id != _requestId || !mounted) return;
      setState(() {
        _error = e is ApiException ? e.message : 'Could not reach the server';
        _loading = false;
      });
    }
  }

  void _onQueryChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 400), () {
      _filters.query = v;
      _load(reset: true);
    });
  }

  Future<void> _openFilters() async {
    final result = await showFilterSheet(context, _filters..query = _searchCtrl.text);
    if (result != null) {
      _filters = result;
      _load(reset: true);
    }
  }

  Future<void> _apply(Map<String, dynamic> item) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ApiService.applyToTuition((item['id'] as num).toInt());
      messenger.showSnackBar(const SnackBar(content: Text('Application sent')));
    } on ApiException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final quick = ['All', ...kSubjects.take(7)];
    final count = _filters.activeCount;

    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          Container(
            color: scheme.primaryContainer,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Column(children: [
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<int>(
                  segments: const [
                    ButtonSegment(value: 0, icon: Icon(Icons.menu_book_outlined), label: Text('Find tuition')),
                    ButtonSegment(value: 1, icon: Icon(Icons.school_outlined), label: Text('Find tutor')),
                  ],
                  selected: {_mode},
                  onSelectionChanged: (s) {
                    _mode = s.first;
                    _load(reset: true);
                  },
                ),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    onChanged: _onQueryChanged,
                    textInputAction: TextInputAction.search,
                    decoration: InputDecoration(
                      hintText: 'Search subject, area, name…',
                      prefixIcon: const Icon(Icons.search),
                      filled: true,
                      fillColor: scheme.surface,
                      contentPadding: EdgeInsets.zero,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Badge(
                  isLabelVisible: count > 0,
                  label: Text('$count'),
                  child: IconButton.filled(
                    onPressed: _openFilters,
                    icon: const Icon(Icons.tune),
                  ),
                ),
              ]),
            ]),
          ),
          SizedBox(
            height: 52,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: quick.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final label = quick[i];
                final selected = label == 'All'
                    ? _filters.subjects.isEmpty
                    : _filters.subjects.length == 1 && _filters.subjects.contains(label);
                return ChoiceChip(
                  label: Text(label),
                  selected: selected,
                  onSelected: (_) {
                    _filters.subjects = label == 'All' ? <String>{} : {label};
                    _load(reset: true);
                  },
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                _loading && _items.isEmpty ? 'Searching…' : '$_total result${_total == 1 ? '' : 's'}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ),
          Expanded(child: _buildList()),
        ]),
      ),
    );
  }

  Widget _buildList() {
    if (_error != null && _items.isEmpty) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(_error!),
          const SizedBox(height: 8),
          OutlinedButton(onPressed: () => _load(reset: true), child: const Text('Retry')),
        ]),
      );
    }
    if (!_loading && _items.isEmpty) {
      return const Center(child: Text('No results. Try widening the radius or clearing filters.'));
    }
    return RefreshIndicator(
      onRefresh: () => _load(reset: true),
      child: ListView.builder(
        controller: _scroll,
        padding: const EdgeInsets.all(12),
        itemCount: _items.length + (_loading || _hasMore ? 1 : 0),
        itemBuilder: (_, i) {
          if (i >= _items.length) {
            return const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final item = _items[i];
          return _mode == 0
              ? TuitionCard(item: item, onApply: () => _apply(item))
              : TutorCard(item: item);
        },
      ),
    );
  }
}
