/**
 * kidsApp.js — Effective Kids Learning Wing: Core SPA State Manager
 * ═══════════════════════════════════════════════════════════════
 * This is a REFERENCE EXPORT of the Kids Wing logic that is already
 * live, tested, and running inline inside index.html (in the site's
 * single <script> block, same as every other module — Academy,
 * Community, Admin, etc. all follow that pattern).
 *
 * This file exists so you have a clean, standalone, documented copy
 * for review or future modularization. It is NOT currently loaded
 * separately by index.html — the working copy is inline. If you
 * want to actually split it out:
 *   1. Add <script src="/js/kidsApp.js" defer></script> to index.html
 *   2. Remove the matching block from the inline <script>
 *   3. Serve this file from the same origin (Cloudflare/cPanel/Render)
 *
 * DEPENDENCIES (must already exist on window before this runs —
 * all defined earlier in index.html's main script):
 *   - AppState        → single-source-of-truth store (coins, cart, kidsProgress)
 *   - escapeHtml(str)  → XSS-safe text insertion
 *   - showToast(msg)   → toast notification UI
 *   - go(id)           → SPA page router (calls setKidsLang/kwUpdateStarsUI on 'kids')
 *
 * COVERS:
 *   - Module rendering (11 modules: Phonics, Tracing, CVC, Math, Sensory,
 *     Science, Rhymes, Arabic/Ethics, Abacus, Brain Games, Worksheets)
 *   - Trilingual UI (bn/en/ar) via KIDS_I18N + setKidsLang()
 *   - Audio-first navigation via speakBn() (Web Speech API / SpeechSynthesis)
 *   - Star/coin reward system (kidsMarkDone → AppState.addCoin + star badges)
 *   - Parent Dashboard: PIN lock (client-side deterrent — see note below),
 *     screen-time setting, progress summary
 *   - Interactive Abacus (HTML5 Canvas, Soroban-style, Web Audio bead clicks)
 *   - Brain Games (memory-match game engine)
 *   - Printable Worksheets (window.print())
 *
 * ⚠️ SECURITY NOTE on the Parent PIN: it is stored in localStorage in
 * plain text and checked entirely client-side. This is a UX deterrent
 * to stop a young child from casually opening parent settings — it is
 * NOT real access control (any adult with browser devtools can bypass
 * it). Don't rely on it to gate anything sensitive like payments.
 */

// ══════════════════════════════════════════════════════
// 🧸 KIDS LEARNING WING — module logic, progress tracking
//    (progress stored via AppState under the 'kidsProgress' key —
//    same single-source-of-truth store as coins/cart)
// ══════════════════════════════════════════════════════
function kidsProgress(){
  return AppState.get('kidsProgress') || {};
}
function kidsTotalStars(){
  const p = kidsProgress();
  return Object.values(p).reduce((a,b)=>a+b, 0);
}
function kwUpdateStarsUI(){
  const total = kidsTotalStars();
  const headerEl = document.getElementById('kwStarsCount');
  if(headerEl) headerEl.textContent = total;
  const parentEl = document.getElementById('kwParentStars');
  if(parentEl) parentEl.textContent = total;
  const p = kidsProgress();
  Object.keys(p).forEach(moduleId=>{
    const badge = document.getElementById('kwStar-'+moduleId);
    if(badge) badge.textContent = '⭐'.repeat(Math.min(p[moduleId], 3));
  });
}
function kidsMarkDone(moduleId, label){
  const p = kidsProgress();
  p[moduleId] = (p[moduleId]||0) + 1;
  AppState.set('kidsProgress', p);
  AppState.addCoin(5);
  kwUpdateStarsUI();
  showToast('⭐ চমৎকার! +৫ Gold Coin অর্জন করেছো — '+escapeHtml(label));
}

function toggleKidsPlayMode(){
  const hero = document.getElementById('kwHero');
  const btn = document.getElementById('kwPlayModeBtn');
  if(!hero||!btn) return;
  const on = hero.classList.toggle('kw-play-mode');
  btn.textContent = on ? '✅ Play Mode চালু' : (KIDS_I18N[kwCurrentLang]?.hero_btn || 'Play & Learn Mode 🎮');
  if(on) showToast('🎮 Play & Learn Mode চালু হয়েছে!');
}

function filterKidsAge(age, btnEl){
  document.querySelectorAll('.kw-age-tab').forEach(t=>t.classList.remove('on'));
  if(btnEl) btnEl.classList.add('on');
  document.querySelectorAll('#kwModuleGrid .kw-card').forEach(card=>{
    const cardAge = card.getAttribute('data-age');
    card.style.display = (age==='all' || cardAge==='all' || cardAge===age) ? '' : 'none';
  });
}

// ── 🌐 Trilingual UI (Bangla / English / Arabic) ──
const KIDS_I18N = {
  bn: {
    hero_badge:'🌟 Ultimate Early Learning Ecosystem', hero_title:'Effective Kids & Baby World',
    hero_sub:'প্লে-গ্রুপ থেকে ৫ম শ্রেণী — Phonics, Tracing, CVC, Math ও নীতিশিক্ষার সবচেয়ে বর্ণিল অভিজ্ঞতা। প্রতিটি অ্যাক্টিভিটি শেষে Gold Coin রিওয়ার্ড!',
    hero_btn:'Play & Learn Mode 🎮',
    age_all:'🌈 সব বয়স', age_baby:'👶 Baby (১–৩ বছর)', age_pre:'🧒 Pre-School (৩–৫ বছর)', age_primary:'🎒 Primary (৬–১০ বছর)',
    t_phonics:'Phonics & Pronunciation', d_phonics:'Letter Sounds, Blends, Digraphs — ট্যাপ করলেই উচ্চারণ শুনবে।',
    t_tracing:'Alphabet & Tracing', d_tracing:'বাংলা ও ইংরেজি বর্ণমালা চেনা এবং টাচ ট্রেসিং চর্চা।',
    t_cvc:'CVC & Sight Words', d_cvc:'৩-অক্ষরের শব্দ বানান, স্বরবর্ণ ও পঠন দক্ষতা।',
    t_math:'Numbers & Math Fun', d_math:'১-১০০ গণনা, নামতা, যোগ-বিয়োগ ও শেপস গেম।',
    t_sensory:'Colors & Sensory', d_sensory:'পশুপাখির ডাক, রঙ চেনা, শেপস এবং ঘুমপাড়ানি গান।',
    t_science:'General Science & World', d_science:'সৌরমণ্ডল, উদ্ভিদ, মানবদেহ ও বিশ্ব পরিচয়ের গল্প।',
    t_rhymes:'Animated Rhymes', d_rhymes:'ইংরেজি ও বাংলা ছড়া, অ্যানিমেটেড কার্টুন ভিডিও।',
    t_ethics:'আরবি বর্ণমালা, Ethics & Dua', d_ethics:'হিজায়ি হরফ, আদব-কায়দা ও দৈনন্দিন দোয়া — উচ্চারণসহ।',
    t_abacus:'Abacus & Mental Math', d_abacus:'ডিজিটাল অ্যাবাকাস বিডস দিয়ে দ্রুত গণনা শেখা।',
    t_brain:'Brain Games & Logic', d_brain:'মেমোরি ম্যাচিং গেম দিয়ে স্মৃতিশক্তি ও লজিক চর্চা।',
    t_worksheets:'Printable Worksheets', d_worksheets:'ট্রেসিং শিট প্রিন্ট করে অফলাইনেও অনুশীলন করুন।',
    parent_title:'🔒 Parent & Guardian Zone', parent_desc:'স্ক্রিন টাইম সেট করুন এবং বাচ্চার অগ্রগতির রিপোর্ট দেখুন।'
  },
  en: {
    hero_badge:'🌟 Ultimate Early Learning Ecosystem', hero_title:'Effective Kids & Baby World',
    hero_sub:'Playgroup to Class 5 — the most colorful Phonics, Tracing, CVC, Math and Ethics experience. Earn Gold Coins after every activity!',
    hero_btn:'Play & Learn Mode 🎮',
    age_all:'🌈 All Ages', age_baby:'👶 Baby (1–3 yrs)', age_pre:'🧒 Pre-School (3–5 yrs)', age_primary:'🎒 Primary (6–10 yrs)',
    t_phonics:'Phonics & Pronunciation', d_phonics:'Letter sounds, blends, digraphs — tap to hear the pronunciation.',
    t_tracing:'Alphabet & Tracing', d_tracing:'Recognize Bangla & English alphabets and practice touch tracing.',
    t_cvc:'CVC & Sight Words', d_cvc:'Build 3-letter words, learn vowels and reading fluency.',
    t_math:'Numbers & Math Fun', d_math:'Count 1–100, times tables, addition-subtraction and shape games.',
    t_sensory:'Colors & Sensory', d_sensory:'Animal sounds, color recognition, shapes and bedtime lullabies.',
    t_science:'General Science & World', d_science:'Solar system, plants, human body and world discovery stories.',
    t_rhymes:'Animated Rhymes', d_rhymes:'English & Bangla rhymes with animated cartoon videos.',
    t_ethics:'Arabic Letters, Ethics & Dua', d_ethics:'Hijaiyah letters, daily etiquette and Duas — with pronunciation.',
    t_abacus:'Abacus & Mental Math', d_abacus:'Learn rapid calculation with a digital abacus bead frame.',
    t_brain:'Brain Games & Logic', d_brain:'Memory matching games to build memory and logic skills.',
    t_worksheets:'Printable Worksheets', d_worksheets:'Print tracing sheets to practice offline too.',
    parent_title:'🔒 Parent & Guardian Zone', parent_desc:'Set screen time limits and view your child\'s progress report.'
  },
  ar: {
    hero_badge:'🌟 أفضل نظام تعليمي مبكر', hero_title:'عالم Effective للأطفال',
    hero_sub:'من الروضة إلى الصف الخامس — أكثر تجربة تعليمية حيوية في الصوتيات والتتبع والرياضيات والأخلاق. اكسب عملات ذهبية بعد كل نشاط!',
    hero_btn:'وضع اللعب والتعلم 🎮',
    age_all:'🌈 كل الأعمار', age_baby:'👶 رضّع (١–٣ سنوات)', age_pre:'🧒 ما قبل المدرسة (٣–٥)', age_primary:'🎒 ابتدائي (٦–١٠)',
    t_phonics:'الصوتيات والنطق', d_phonics:'أصوات الحروف — اضغط للاستماع للنطق.',
    t_tracing:'الحروف والتتبع', d_tracing:'تعرف على الحروف البنغالية والإنجليزية وتدرب على التتبع.',
    t_cvc:'كلمات CVC', d_cvc:'بناء كلمات من ٣ أحرف وتعلم حروف العلة والقراءة.',
    t_math:'الأرقام والرياضيات', d_math:'العد من ١ إلى ١٠٠، الجدول، الجمع والطرح وألعاب الأشكال.',
    t_sensory:'الألوان والحواس', d_sensory:'أصوات الحيوانات، تمييز الألوان والأشكال وأغاني النوم.',
    t_science:'العلوم العامة والعالم', d_science:'قصص عن المجموعة الشمسية والنباتات وجسم الإنسان.',
    t_rhymes:'أناشيد متحركة', d_rhymes:'أناشيد إنجليزية وبنغالية بفيديوهات متحركة.',
    t_ethics:'الحروف العربية والأخلاق والدعاء', d_ethics:'حروف الهجائية، الآداب اليومية والأدعية — مع النطق.',
    t_abacus:'العداد الذهني (Abacus)', d_abacus:'تعلم الحساب السريع باستخدام إطار خرز رقمي.',
    t_brain:'ألعاب العقل والمنطق', d_brain:'ألعاب مطابقة الذاكرة لتقوية الذاكرة والمنطق.',
    t_worksheets:'أوراق عمل للطباعة', d_worksheets:'اطبع أوراق التتبع للتدرب دون اتصال أيضاً.',
    parent_title:'🔒 منطقة الوالدين', parent_desc:'حدد وقت الشاشة اليومي وتابع تقرير تقدم طفلك.'
  }
};
let kwCurrentLang = 'bn';
function setKidsLang(lang){
  if(!KIDS_I18N[lang]) return;
  kwCurrentLang = lang;
  const dict = KIDS_I18N[lang];
  document.querySelectorAll('#page-kids [data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(dict[key]) el.textContent = dict[key];
  });
  document.querySelectorAll('.kw-lang-btn').forEach(b=>b.classList.remove('on'));
  const activeBtn = document.getElementById('kwLangBtn-'+lang);
  if(activeBtn) activeBtn.classList.add('on');
  const kidsPage = document.getElementById('page-kids');
  if(kidsPage) kidsPage.setAttribute('dir', lang==='ar' ? 'rtl' : 'ltr');
  try{ localStorage.setItem('eeh_kids_lang', lang); }catch(e){}
}

// ── 🔐 Parent PIN lock (client-side deterrent, not real security — see docs) ──
function kwGetPin(){ try{ return localStorage.getItem('eeh_kids_pin'); }catch(e){ return null; } }
function kwPinVerifiedThisSession(){ return sessionStorage.getItem('eeh_kids_pin_ok')==='1'; }

function kwCheckPin(){
  const input = document.getElementById('kwPinInput');
  const err = document.getElementById('kwPinError');
  if(input.value === kwGetPin()){
    sessionStorage.setItem('eeh_kids_pin_ok','1');
    document.getElementById('kwPinGate').style.display='none';
    document.getElementById('kwParentContent').style.display='block';
    input.value='';
    err.style.display='none';
  } else {
    err.style.display='block';
    input.value='';
  }
}
function kwSetPin(){
  const val = document.getElementById('kwPinSetupInput').value;
  if(!/^\d{4}$/.test(val)){ showToast('৪-সংখ্যার PIN দিন'); return; }
  try{ localStorage.setItem('eeh_kids_pin', val); }catch(e){}
  sessionStorage.setItem('eeh_kids_pin_ok','1');
  document.getElementById('kwPinSetupPrompt').style.display='none';
  document.getElementById('kwChangePinBtn').style.display='block';
  showToast('🔐 PIN সেট করা হয়েছে');
}
function kwChangePin(){
  try{ localStorage.removeItem('eeh_kids_pin'); }catch(e){}
  sessionStorage.removeItem('eeh_kids_pin_ok');
  const prompt = document.getElementById('kwPinSetupPrompt');
  if(prompt) prompt.style.display='block';
  document.getElementById('kwChangePinBtn').style.display='none';
  showToast('আগের PIN মুছে ফেলা হয়েছে — নতুন PIN সেট করুন');
}

function speakBn(text, lang){
  try{
    if(!('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang || 'en-US';
    u.rate = 0.85;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  }catch(e){ /* speech not available — silently skip, buttons still work visually */ }
}

function openKidsModule(id){
  const modal = document.getElementById('kwModuleModal');
  const body = document.getElementById('kwModalBody');
  if(!modal||!body) return;
  body.innerHTML = kwModuleTemplates[id] ? kwModuleTemplates[id]() : kwComingSoon(id);
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeKidsModule(){
  const modal = document.getElementById('kwModuleModal');
  if(modal) modal.classList.remove('open');
  document.body.style.overflow = '';
  try{ speechSynthesis.cancel(); }catch(e){}
}

function openKidsParentModal(){
  const modal = document.getElementById('kwParentModal');
  if(!modal) return;
  const gate = document.getElementById('kwPinGate');
  const content = document.getElementById('kwParentContent');
  const pinSet = kwGetPin();

  if(pinSet && !kwPinVerifiedThisSession()){
    gate.style.display='block';
    content.style.display='none';
  } else {
    gate.style.display='none';
    content.style.display='block';
    document.getElementById('kwPinSetupPrompt').style.display = pinSet ? 'none' : 'block';
    document.getElementById('kwChangePinBtn').style.display = pinSet ? 'block' : 'none';

    const saved = AppState.get('kidsScreenTime');
    const sel = document.getElementById('kwScreenTimeSelect');
    if(sel && saved) sel.value = saved;
    const p = kidsProgress();
    const entries = Object.entries(p);
    const summary = document.getElementById('kwProgressSummary');
    if(summary){
      summary.innerHTML = entries.length
        ? entries.map(([k,v])=>`✓ ${escapeHtml(kwModuleNames[k]||k)}: ${v} বার সম্পন্ন`).join('<br>')
        : 'এখনো কোনো অ্যাক্টিভিটি সম্পন্ন হয়নি।';
    }
    kwUpdateStarsUI();
  }
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeKidsParentModal(){
  const modal = document.getElementById('kwParentModal');
  if(modal) modal.classList.remove('open');
  document.body.style.overflow = '';
}
function setKidsScreenTime(minutes){
  AppState.set('kidsScreenTime', minutes);
  showToast(minutes==='0' ? '⏱ স্ক্রিন টাইম সীমা তুলে দেওয়া হয়েছে' : `⏱ দৈনিক সীমা ${minutes} মিনিট সেট হয়েছে`);
}

const kwModuleNames = {
  phonics:'Phonics & Pronunciation', tracing:'Alphabet & Tracing', cvc:'CVC & Sight Words',
  math:'Numbers & Math Fun', sensory:'Colors & Sensory', science:'General Science & World',
  rhymes:'Animated Rhymes', ethics:'আরবি বর্ণমালা, Ethics & Dua',
  abacus:'Abacus & Mental Math', brain:'Brain Games & Logic', worksheets:'Printable Worksheets'
};

function kwComingSoon(id){
  const descriptions = {
    sensory:'পশুপাখির ডাক শোনা, রঙ চেনা, শেপস মেলানো এবং ঘুমপাড়ানি গান — বেবিদের জন্য স্পর্শ ও শ্রবণভিত্তিক লার্নিং।',
    science:'সৌরমণ্ডল, উদ্ভিদের জীবনচক্র, মানবদেহের পরিচিতি ও পরিবেশ সচেতনতা — অ্যানিমেটেড গল্পের মাধ্যমে।',
    rhymes:'বাংলা ও ইংরেজি জনপ্রিয় ছড়া, অ্যানিমেটেড ভিডিওসহ — গান গেয়ে গেয়ে ভাষা শেখা।'
  };
  return `
    <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:10px;">${escapeHtml(kwModuleNames[id]||id)}</h3>
    <p style="font-family:'Noto Serif Bengali',serif;font-size:.86rem;color:var(--text2);line-height:1.8;margin-bottom:14px;">${escapeHtml(descriptions[id]||'')}</p>
    <div style="background:var(--gold-dim);border:1px solid rgba(184,109,5,.2);border-radius:var(--r);padding:12px 14px;font-size:.8rem;color:var(--gold);font-weight:600;">🚧 এই মডিউলের ইন্টারেক্টিভ কনটেন্ট শীঘ্রই আসছে।</div>`;
}

const kwModuleTemplates = {
  phonics: function(){
    const letters = [['A','æ'],['B','buh'],['C','kuh'],['D','duh'],['E','eh'],['F','fuh'],['G','guh'],['H','huh'],['I','ih'],['J','juh'],['K','kuh'],['L','luh']];
    const grid = letters.map(([l])=>`<button class="kw-letter-btn" onclick="speakBn('${l}','en-US');kidsMarkDone('phonics','Phonics')">${l}</button>`).join('');
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🔊 Phonics & Pronunciation</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:6px;">প্রতিটি অক্ষরে ট্যাপ করলে উচ্চারণ শুনতে পাবে:</p>
      <div class="kw-letter-grid">${grid}</div>
      <p style="font-size:.72rem;color:var(--text3);">🔈 শব্দ শুনতে ডিভাইসের সাউন্ড চালু রাখুন।</p>`;
  },
  cvc: function(){
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🧩 CVC শব্দ বানাও</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:10px;">C-A-T লেখাটি ক্লিক করে সম্পূর্ণ করো:</p>
      <div class="kw-cvc-slot" id="kwCvcSlots">
        <div class="kw-cvc-box" data-slot="0"></div>
        <div class="kw-cvc-box" data-slot="1"></div>
        <div class="kw-cvc-box" data-slot="2"></div>
      </div>
      <div class="kw-letter-grid" style="max-width:280px;">
        ${['C','A','T'].sort(()=>Math.random()-0.5).map(l=>`<button class="kw-letter-btn" onclick="kwCvcPick('${l}')">${l}</button>`).join('')}
      </div>
      <div id="kwCvcResult" style="margin-top:10px;font-size:.85rem;font-weight:600;"></div>`;
  },
  math: function(){
    const blocks = Array.from({length:10}, (_,i)=>`<div class="kw-count-block" onclick="kwToggleBlock(this,${i+1})">${i+1}</div>`).join('');
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🔢 গণনা শিখি</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:8px;">১ থেকে ১০ পর্যন্ত ব্লকগুলো ক্রমে ট্যাপ করো — প্রতিটির সংখ্যা শুনবে:</p>
      <div class="kw-count-blocks">${blocks}</div>
      <div id="kwMathResult" style="margin-top:10px;font-size:.85rem;font-weight:600;color:var(--amber);"></div>`;
  },
  tracing: function(){
    setTimeout(kwInitTraceCanvas, 50);
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">✍️ ট্রেসিং প্র্যাকটিস</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:6px;">নিচে আঙুল/মাউস দিয়ে আঁকো — অক্ষর 'A' অনুসরণ করার চেষ্টা করো:</p>
      <canvas id="kwTraceCanvas" class="kw-trace-canvas" width="300" height="240"></canvas>
      <div style="display:flex;gap:10px;justify-content:center;">
        <button class="btn-outline btn-sm" onclick="kwClearTrace()">🔄 আবার আঁকো</button>
        <button class="btn-teal btn-sm" onclick="kidsMarkDone('tracing','Tracing')">✓ সম্পন্ন হয়েছে</button>
      </div>`;
  },
  ethics: function(){
    const hijaiyah = [['ا','alif'],['ب','ba'],['ت','ta'],['ث','tha'],['ج','jim'],['ح','ha'],['خ','kha'],['د','dal'],['ذ','dhal'],['ر','ra'],['ز','zay'],['س','sin']];
    const grid = hijaiyah.map(([l])=>`<button class="kw-letter-btn" onclick="speakBn('${l}','ar-SA');kidsMarkDone('ethics','Arabic Letters')" style="font-size:1.6rem;">${l}</button>`).join('');
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🌙 আরবি হিজায়ি হরফ</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:6px;">হরফে ট্যাপ করলে উচ্চারণ শুনবে:</p>
      <div class="kw-letter-grid">${grid}</div>
      <div style="background:var(--teal-dim);border:1px solid rgba(0,122,148,.15);border-radius:var(--r);padding:12px 14px;margin-top:14px;">
        <div style="font-size:.72rem;font-weight:700;color:var(--teal);margin-bottom:6px;">🤲 আজকের দোয়া — খাবার শুরুর দোয়া</div>
        <div style="font-family:'Noto Serif Bengali',serif;font-size:.85rem;color:var(--text);margin-bottom:4px;" dir="rtl">بِسْمِ اللَّهِ</div>
        <div style="font-size:.78rem;color:var(--text2);">উচ্চারণ: বিসমিল্লাহ্ — অর্থ: আল্লাহর নামে (শুরু করছি)</div>
        <button class="btn-teal btn-sm" style="margin-top:10px;" onclick="speakBn('Bismillah','ar-SA');kidsMarkDone('ethics','Dua')">🔊 শুনুন ও সম্পন্ন করুন</button>
      </div>`;
  },
  abacus: function(){
    setTimeout(kwInitAbacus, 50);
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🧮 অ্যাবাকাস দিয়ে গণনা</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:4px;">বিডসগুলো ট্যাপ করে মধ্যরেখার দিকে সরাও:</p>
      <canvas id="kwAbacusCanvas" class="kw-abacus-canvas" width="380" height="260"></canvas>
      <div class="kw-abacus-total">মোট: <span id="kwAbacusTotal">0</span></div>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:10px;">
        <button class="btn-outline btn-sm" onclick="kwResetAbacus()">🔄 রিসেট</button>
        <button class="btn-teal btn-sm" onclick="kidsMarkDone('abacus','Abacus')">✓ সম্পন্ন হয়েছে</button>
      </div>`;
  },
  brain: function(){
    setTimeout(kwInitBrainGame, 50);
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">🧠 মেমোরি ম্যাচিং গেম</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:6px;">একই ইমোজির জোড়া খুঁজে বের করো:</p>
      <div class="kw-brain-grid" id="kwBrainGrid"></div>
      <div id="kwBrainResult" style="margin-top:10px;text-align:center;font-size:.85rem;font-weight:600;color:var(--indigo);"></div>`;
  },
  worksheets: function(){
    return `
      <h3 id="kwModalTitle" style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;margin-bottom:8px;">📝 প্রিন্টযোগ্য ওয়ার্কশিট</h3>
      <p style="font-family:'Noto Serif Bengali',serif;font-size:.82rem;color:var(--text2);margin-bottom:6px;">নিচের বাটনে ক্লিক করে ট্রেসিং শিট প্রিন্ট করো:</p>
      <div class="kw-worksheet-preview">
        <div style="font-family:'Cormorant Garamond',serif;font-size:3rem;letter-spacing:14px;color:var(--border2);">A B C</div>
        <div style="font-size:.72rem;color:var(--text3);margin-top:6px;">প্রিন্ট করলে A-Z ট্রেসিং শিট পাবে (dotted outline সহ)</div>
      </div>
      <div style="display:flex;gap:10px;justify-content:center;">
        <button class="btn-teal btn-sm" onclick="kwPrintWorksheet()">🖨️ প্রিন্ট করুন</button>
        <button class="btn-outline btn-sm" onclick="kidsMarkDone('worksheets','Worksheet')">✓ সম্পন্ন হয়েছে</button>
      </div>
      <div id="kwPrintArea" style="display:none;">
        <h2 style="font-family:'Cormorant Garamond',serif;text-align:center;">Effective Kids — Alphabet Tracing Sheet</h2>
        <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:20px;padding:20px;">
          ${Array.from({length:26},(_,i)=>String.fromCharCode(65+i)).map(l=>`<div style="font-family:'Cormorant Garamond',serif;font-size:2.4rem;text-align:center;border:1px dashed #999;border-radius:8px;padding:10px 0;color:#ccc;">${l}</div>`).join('')}
        </div>
      </div>`;
  }
};

let kwPrintReady = false;
function kwPrintWorksheet(){
  window.print();
}


let kwCvcState = [];
function kwCvcPick(letter){
  if(kwCvcState.length>=3) return;
  kwCvcState.push(letter);
  const slots = document.querySelectorAll('#kwCvcSlots .kw-cvc-box');
  slots[kwCvcState.length-1].textContent = letter;
  speakBn(letter,'en-US');
  if(kwCvcState.length===3){
    const word = kwCvcState.join('');
    const resultEl = document.getElementById('kwCvcResult');
    if(word==='CAT'){
      resultEl.style.color = 'var(--green)';
      resultEl.textContent = '🎉 চমৎকার! CAT = বিড়াল';
      speakBn('Cat! Cat means Biral in Bengali.','en-US');
      kidsMarkDone('cvc','CVC Word Building');
    } else {
      resultEl.style.color = 'var(--red)';
      resultEl.textContent = 'আরেকবার চেষ্টা করো!';
    }
    setTimeout(()=>{
      kwCvcState = [];
      slots.forEach(s=>s.textContent='');
      if(resultEl) resultEl.textContent='';
    }, 1800);
  }
}

let kwCountState = 0;
function kwToggleBlock(el, n){
  if(n !== kwCountState+1) return; // must count in order
  el.classList.add('on');
  kwCountState = n;
  speakBn(String(n),'en-US');
  const resultEl = document.getElementById('kwMathResult');
  if(resultEl) resultEl.textContent = n+' পর্যন্ত গোনা হয়েছে!';
  if(n===10){
    if(resultEl) resultEl.textContent = '🎉 দারুণ! ১০ পর্যন্ত গুনে ফেলেছো!';
    kidsMarkDone('math','Counting 1-10');
    kwCountState = 0;
    setTimeout(()=>{ document.querySelectorAll('.kw-count-block.on').forEach(b=>b.classList.remove('on')); }, 1500);
  }
}

let kwDrawing = false;
function kwInitTraceCanvas(){
  const canvas = document.getElementById('kwTraceCanvas');
  if(!canvas || canvas.dataset.init) return;
  canvas.dataset.init = '1';
  const ctx = canvas.getContext('2d');
  ctx.strokeStyle = 'rgba(192,48,106,.15)';
  ctx.font = '180px Georgia';
  ctx.fillStyle = 'rgba(192,48,106,.12)';
  ctx.fillText('A', 55, 200);
  ctx.strokeStyle = 'var(--rose)';
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';

  function pos(e){
    const r = canvas.getBoundingClientRect();
    const p = e.touches ? e.touches[0] : e;
    return { x: (p.clientX - r.left) * (canvas.width/r.width), y: (p.clientY - r.top) * (canvas.height/r.height) };
  }
  function start(e){ kwDrawing = true; const p = pos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); e.preventDefault(); }
  function move(e){ if(!kwDrawing) return; const p = pos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); e.preventDefault(); }
  function end(){ kwDrawing = false; }

  canvas.addEventListener('mousedown', start);
  canvas.addEventListener('mousemove', move);
  window.addEventListener('mouseup', end);
  canvas.addEventListener('touchstart', start, {passive:false});
  canvas.addEventListener('touchmove', move, {passive:false});
  canvas.addEventListener('touchend', end);
}
function kwClearTrace(){
  const canvas = document.getElementById('kwTraceCanvas');
  if(!canvas) return;
  canvas.dataset.init = '';
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,canvas.width,canvas.height);
  kwInitTraceCanvas();
}

// ── 🧮 Abacus (Soroban-style, 4 rods: place values 1000/100/10/1) ──
let kwAbacusRods = [];
function kwBeadSound(){
  try{
    const ctx = new (window.AudioContext||window.webkitAudioContext)();
    const osc = ctx.createOscillator(), gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime+0.04);
    gain.gain.setValueAtTime(0.25, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.01, ctx.currentTime+0.04);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime+0.04);
  }catch(e){ /* Web Audio unavailable — silently skip, beads still move */ }
}
function kwDrawAbacus(){
  const canvas = document.getElementById('kwAbacusCanvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const RODS = 4, VALUES = [1000,100,10,1];
  const RX=20, RY=11, margin=26, beamY=95;
  const spacing = (canvas.width - margin*2) / (RODS+1);
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.lineWidth=10; ctx.strokeStyle='#8D6E4A';
  ctx.strokeRect(margin,margin,canvas.width-margin*2,canvas.height-margin*2);
  ctx.lineWidth=7; ctx.strokeStyle='#3E2723';
  ctx.beginPath(); ctx.moveTo(margin,beamY); ctx.lineTo(canvas.width-margin,beamY); ctx.stroke();

  function bead(x,y,color){
    ctx.save();
    ctx.beginPath(); ctx.ellipse(x,y,RX,RY,0,0,2*Math.PI);
    ctx.fillStyle=color; ctx.fill();
    ctx.lineWidth=2; ctx.strokeStyle='#FFF'; ctx.stroke();
    ctx.beginPath(); ctx.ellipse(x-5,y-3,RX/3,RY/3,0,0,2*Math.PI);
    ctx.fillStyle='rgba(255,255,255,.4)'; ctx.fill();
    ctx.restore();
  }

  let total=0;
  for(let i=0;i<RODS;i++){
    const x = margin + spacing*(i+1);
    ctx.lineWidth=3; ctx.strokeStyle='#BCAAA4';
    ctx.beginPath(); ctx.moveTo(x,margin); ctx.lineTo(x,canvas.height-margin); ctx.stroke();
    const r = kwAbacusRods[i];
    total += ((r.upper?5:0) + r.lower) * VALUES[i];
    const upperY = r.upper ? (beamY-RY-3) : (margin+RY+3);
    bead(x, upperY, '#E91E63');
    for(let j=0;j<4;j++){
      let y;
      if(j < r.lower) y = beamY+RY+3+(j*(RY*2+2));
      else y = (canvas.height-margin)-RY-3-((3-j)*(RY*2+2));
      bead(x, y, '#0288D1');
    }
  }
  const totalEl = document.getElementById('kwAbacusTotal');
  if(totalEl) totalEl.textContent = total.toLocaleString('bn-BD');
  return total;
}
function kwInitAbacus(){
  const canvas = document.getElementById('kwAbacusCanvas');
  if(!canvas || canvas.dataset.init) { if(canvas) kwDrawAbacus(); return; }
  canvas.dataset.init='1';
  kwAbacusRods = Array.from({length:4},()=>({upper:false,lower:0}));
  const RODS=4, margin=26, beamY=95;
  const spacing = (canvas.width - margin*2) / (RODS+1);

  function handle(e){
    const rect = canvas.getBoundingClientRect();
    const p = e.touches ? e.touches[0] : e;
    const x = (p.clientX-rect.left) * (canvas.width/rect.width);
    const y = (p.clientY-rect.top) * (canvas.height/rect.height);
    for(let i=0;i<RODS;i++){
      const rodX = margin + spacing*(i+1);
      if(Math.abs(x-rodX) < 24){
        if(y < beamY){
          kwAbacusRods[i].upper = !kwAbacusRods[i].upper;
        } else {
          const idx = Math.floor((y-beamY)/26)+1;
          if(kwAbacusRods[i].lower >= idx) kwAbacusRods[i].lower = idx-1;
          else kwAbacusRods[i].lower = Math.min(4, idx);
        }
        kwBeadSound();
        const total = kwDrawAbacus();
        if(total===10 || total===50 || total===100) kidsMarkDone('abacus','Abacus milestone');
        break;
      }
    }
    e.preventDefault();
  }
  canvas.addEventListener('mousedown', handle);
  canvas.addEventListener('touchstart', handle, {passive:false});
  kwDrawAbacus();
}
function kwResetAbacus(){
  const canvas = document.getElementById('kwAbacusCanvas');
  if(canvas) canvas.dataset.init='';
  kwInitAbacus();
}

// ── 🧠 Brain Game — emoji memory match (4x4, 8 pairs) ──
let kwBrainState = { cards:[], flipped:[], matched:0 };
function kwInitBrainGame(){
  const grid = document.getElementById('kwBrainGrid');
  if(!grid) return;
  const emojis = ['🐶','🐱','🐰','🐻','🦁','🐸','🐵','🐷'];
  let deck = [...emojis, ...emojis].sort(()=>Math.random()-0.5);
  kwBrainState = { cards: deck, flipped: [], matched: 0 };
  grid.innerHTML = deck.map((e,i)=>`<div class="kw-brain-tile" data-idx="${i}" onclick="kwFlipBrainTile(${i})">❓</div>`).join('');
}
function kwFlipBrainTile(idx){
  const tiles = document.querySelectorAll('#kwBrainGrid .kw-brain-tile');
  const tile = tiles[idx];
  if(!tile || tile.classList.contains('flipped') || tile.classList.contains('matched') || kwBrainState.flipped.length>=2) return;
  tile.textContent = kwBrainState.cards[idx];
  tile.classList.add('flipped');
  kwBrainState.flipped.push(idx);
  if(kwBrainState.flipped.length===2){
    const [a,b] = kwBrainState.flipped;
    if(kwBrainState.cards[a]===kwBrainState.cards[b]){
      tiles[a].classList.add('matched'); tiles[b].classList.add('matched');
      kwBrainState.flipped = [];
      kwBrainState.matched++;
      const resultEl = document.getElementById('kwBrainResult');
      if(kwBrainState.matched===8){
        if(resultEl) resultEl.textContent = '🎉 দারুণ! সব জোড়া মিলিয়ে ফেলেছো!';
        kidsMarkDone('brain','Memory Match');
      } else if(resultEl){
        resultEl.textContent = kwBrainState.matched+'/৮ জোড়া মিলেছে!';
      }
    } else {
      setTimeout(()=>{
        tiles[a].textContent='❓'; tiles[b].textContent='❓';
        tiles[a].classList.remove('flipped'); tiles[b].classList.remove('flipped');
        kwBrainState.flipped = [];
      }, 700);
    }
  }
}

