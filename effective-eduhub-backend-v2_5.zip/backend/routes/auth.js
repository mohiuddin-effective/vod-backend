const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db/pool');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET;
const TOKEN_TTL = '12h';

// POST /auth/login  { email, password }
router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email_and_password_required' });
  if (!JWT_SECRET) return res.status(500).json({ error: 'server_misconfigured' });

  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email.toLowerCase()]);
    const user = rows[0];
    if (!user) return res.status(401).json({ error: 'invalid_credentials' });

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'invalid_credentials' });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: TOKEN_TTL }
    );
    res.json({
      ok: true,
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    console.error('[auth/login] error:', err);
    res.status(500).json({ error: 'internal_error' });
  }
});

// POST /auth/register  { name, email, password, role }
// role is restricted to self-serve roles; admins are only created via db/seed.js
router.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body || {};
  const allowedRoles = ['student', 'teacher', 'publisher', 'seller'];
  if (!name || !email || !password) return res.status(400).json({ error: 'name_email_password_required' });
  if (!allowedRoles.includes(role)) return res.status(400).json({ error: 'invalid_role' });

  try {
    const hash = await bcrypt.hash(password, 10);
    const { rows } = await pool.query(
      `INSERT INTO users (name, email, password_hash, role)
       VALUES ($1,$2,$3,$4) RETURNING id, name, email, role`,
      [name, email.toLowerCase(), hash, role]
    );
    res.status(201).json({ ok: true, user: rows[0] });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'email_already_registered' });
    console.error('[auth/register] error:', err);
    res.status(500).json({ error: 'internal_error' });
  }
});

module.exports = router;
