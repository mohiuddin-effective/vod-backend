require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('./pool');

// The first admin account is created from environment variables so no real
// password ever lives in source control. Set ADMIN_EMAIL / ADMIN_PASSWORD
// in your .env (or Render env vars) before running `npm run seed`.
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@effectiveeducationhub.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || null;

async function seed() {
  if (!ADMIN_PASSWORD) {
    console.error('[seed] Set ADMIN_PASSWORD in your environment before seeding. Aborting.');
    process.exit(1);
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // 1. Admin user (idempotent)
    const adminHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    const adminRes = await client.query(
      `INSERT INTO users (name, email, password_hash, role, is_verified)
       VALUES ($1,$2,$3,'admin',TRUE)
       ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash
       RETURNING id`,
      ['Admin', ADMIN_EMAIL, adminHash]
    );
    console.log(`[seed] admin ready: ${ADMIN_EMAIL} (id ${adminRes.rows[0].id})`);

    // 2. A couple of sample teachers so the dashboards aren't empty on first run
    const samplePassHash = await bcrypt.hash('ChangeMe123!', 10);
    const teacherNames = [
      ['ফারহানা বেগম', 'farhana@example.com'],
      ['মোহাম্মদ আলী', 'ali@example.com'],
      ['সাবিনা ইসলাম', 'sabina@example.com']
    ];
    const teacherIds = [];
    for (const [name, email] of teacherNames) {
      const r = await client.query(
        `INSERT INTO users (name, email, password_hash, role, is_verified, nid_verified, bank_verified)
         VALUES ($1,$2,$3,'teacher',TRUE,TRUE,TRUE)
         ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [name, email, samplePassHash]
      );
      teacherIds.push(r.rows[0].id);
    }

    // 3. Sample pending course for the approval queue
    await client.query(
      `INSERT INTO courses (title, teacher_id, category, price, status, ai_quality_score)
       SELECT 'IELTS Writing Master', $1, 'IELTS', 1500, 'pending', 92
       WHERE NOT EXISTS (SELECT 1 FROM courses WHERE title = 'IELTS Writing Master')`,
      [teacherIds[0]]
    );

    // 4. Sample payouts so the payout tab has real rows
    const payoutSeed = [
      [teacherIds[0], 40000, 'paid'],
      [teacherIds[1], 56250, 'pending'],
      [teacherIds[2], 47500, 'paid']
    ];
    for (const [teacherId, total, status] of payoutSeed) {
      const exists = await client.query(
        'SELECT 1 FROM payouts WHERE teacher_id = $1 AND total_sales = $2', [teacherId, total]
      );
      if (exists.rowCount === 0) {
        await client.query(
          `INSERT INTO payouts (teacher_id, total_sales, platform_cut_pct, status, period_label, paid_at)
           VALUES ($1,$2,20,$3,'2026-08', CASE WHEN $3 = 'paid' THEN now() ELSE NULL END)`,
          [teacherId, total, status]
        );
      }
    }

    await client.query('COMMIT');
    console.log('[seed] done.');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch(err => {
  console.error('[seed] failed:', err);
  process.exit(1);
});
