import { z } from 'zod';

const csv = z.string().optional().transform((v) =>
  v ? v.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 12) : undefined);

// Shared query-string contract for BOTH search endpoints.
// Budget filters are compared against the *monthly-equivalent* of each post.
export const searchSchema = z.object({
  q: z.string().trim().max(100).optional(),
  subject: csv,                 // "Physics,ICT"  (matches ANY)
  class_level: csv,             // "Class 9,Class 10"
  lat: z.coerce.number().min(-90).max(90).optional(),
  lng: z.coerce.number().min(-180).max(180).optional(),
  radius_km: z.coerce.number().min(0.5).max(50).default(5),
  budget_min: z.coerce.number().min(0).optional(),
  budget_max: z.coerce.number().min(0).optional(),
  rate_type: z.enum(['hourly', 'weekly', 'monthly']).optional(),
  days_min: z.coerce.number().int().min(1).max(7).optional(),
  days_max: z.coerce.number().int().min(1).max(7).optional(),
  hours_min: z.coerce.number().min(0.5).max(12).optional(),
  hours_max: z.coerce.number().min(0.5).max(12).optional(),
  gender: z.enum(['male', 'female', 'any']).optional(),
  sort: z.enum(['newest', 'distance', 'budget_low', 'budget_high']).default('newest'),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(50).default(20),
}).refine((d) => (d.lat === undefined) === (d.lng === undefined),
  { message: 'lat and lng must be provided together', path: ['lat'] });

// Positional-parameter collector: P.add(value) -> "$n"
export function makeParams() {
  const values = [];
  return { values, add(v) { values.push(v); return `$${values.length}`; } };
}

export const likePattern = (s) => `%${s.replace(/[\\%_]/g, '\\$&')}%`;

export const pointSql = (P, lat, lng) =>
  `ST_SetSRID(ST_MakePoint(${P.add(lng)}::float8, ${P.add(lat)}::float8), 4326)::geography`;

export const meta = (rows, f) => ({ page: f.page, limit: f.limit, total: rows[0]?.total ?? 0 });
export const stripTotal = (rows) => rows.map(({ total, ...r }) => r);
