// router.param('id', validateId): reject non-numeric / oversized ids before they reach Postgres
// (BIGINT ids; 18 digits always fit). Prevents 500s from "invalid input syntax for type bigint".
export const validateId = (_req, res, next, id) =>
  /^\d{1,18}$/.test(id) ? next() : res.status(404).json({ error: 'Not found' });
