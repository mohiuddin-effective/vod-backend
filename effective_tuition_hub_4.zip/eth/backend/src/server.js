import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { ZodError } from 'zod';
import authRoutes from './routes/auth.js';
import tuitionRoutes from './routes/tuitionPosts.js';
import tutorRoutes from './routes/tutorPosts.js';
import feedRoutes from './routes/feed.js';
import { pool, query } from './db.js';

if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is not set');

const app = express();
// Behind a reverse proxy / load balancer, set TRUST_PROXY to the number of proxy hops (e.g. 1)
// so rate limiting and logs see the real client IP instead of the proxy's.
if (process.env.TRUST_PROXY) {
  const tp = process.env.TRUST_PROXY;
  app.set('trust proxy', /^\d+$/.test(tp) ? Number(tp) : tp);
}
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '100kb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));
// Limiters answer in JSON like every other error, so clients can parse them.
const limiter = (windowMs, limit) => rateLimit({
  windowMs, limit, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Too many requests, please try again later.' },
});
app.use('/api/auth', limiter(15 * 60 * 1000, Number(process.env.RATE_AUTH_MAX) || 50), authRoutes);
app.use('/api/tuition-posts', limiter(60 * 1000, 120), tuitionRoutes);
app.use('/api/tutor-posts', limiter(60 * 1000, 120), tutorRoutes);
app.use('/api/feed', limiter(60 * 1000, 120), feedRoutes);

app.use((_req, res) => res.status(404).json({ error: 'Not found' }));

// Express 5 forwards rejected async handlers here automatically
app.use((err, _req, res, _next) => {
  if (err instanceof ZodError) {
    return res.status(400).json({
      error: err.issues.map((i) => `${i.path.join('.') || 'body'}: ${i.message}`).join('; '),
      details: err.issues,
    });
  }
  // body-parser errors (malformed JSON, payload too large, ...) carry a 4xx status
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body too large' });
  if (err.code === '23505') return res.status(409).json({ error: 'Email or phone already registered' });
  if (err.code === '22P02' || err.code === '22003') return res.status(400).json({ error: 'Invalid value in request' });
  if (err.status >= 400 && err.status < 500) return res.status(err.status).json({ error: 'Bad request' });
  // Overload protection: pool exhausted (connectionTimeoutMillis) or statement_timeout hit
  if (err.code === '57014' || /timeout exceeded when trying to connect/i.test(err.message)) {
    res.set('Retry-After', '1');
    return res.status(503).json({ success: false, error: 'Server busy, please retry shortly' });
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// Mark lapsed posts as expired so every status check agrees with what search already hides.
// Idempotent, so it is safe with several API instances.
async function sweepExpired() {
  try {
    await query(`UPDATE tuition_posts SET status = 'expired' WHERE status = 'active' AND expires_at <= now()`);
    await query(`UPDATE tutor_availability_posts SET status = 'expired' WHERE status = 'active' AND expires_at <= now()`);
  } catch (e) {
    console.error('expiry sweep failed:', e.message);
  }
}
const sweepTimer = setInterval(sweepExpired, Number(process.env.EXPIRY_SWEEP_MS) || 15 * 60 * 1000);
sweepTimer.unref();
sweepExpired();

const port = process.env.PORT || 4000;
const server = app.listen(port, () => console.log(`API listening on :${port}`));

// Graceful shutdown: stop accepting requests, let in-flight ones finish, then drain the pool.
function shutdown(signal) {
  console.log(`${signal} received, shutting down`);
  server.close(async () => { await pool.end().catch(() => {}); process.exit(0); });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
