import crypto from 'node:crypto';
import { z, ZodError } from 'zod';
import { query } from '../db.js';

// ───────────────────────── input ─────────────────────────
const blankToUndef = (schema) => z.preprocess((v) => (v === '' ? undefined : v), schema.optional());

const feedQuerySchema = z.object({
  query: blankToUndef(z.string().trim().max(100)),
  lat: blankToUndef(z.coerce.number().min(-90).max(90)),
  lng: blankToUndef(z.coerce.number().min(-180).max(180)),
  radius_km: z.preprocess((v) => (v === '' ? undefined : v), z.coerce.number().min(1).max(500).default(50)),
  limit: z.preprocess((v) => (v === '' ? undefined : v), z.coerce.number().int().min(1).max(50).default(20)),
  cursor: blankToUndef(z.string().max(600)),
}).superRefine((v, ctx) => {
  if ((v.lat === undefined) !== (v.lng === undefined))
    ctx.addIssue({ code: 'custom', path: ['lat'], message: 'lat and lng must be provided together' });
  if (!v.query && v.lat === undefined)
    // Without a text filter or a location filter there is nothing selective to use an index for:
    // every live post would have to be scored on every page.
    ctx.addIssue({ code: 'custom', path: ['query'], message: 'provide a search query, or lat and lng' });
});

// A cursor is opaque to clients: base64url(JSON). Everything in it is validated, then bound as a parameter.
const cursorSchema = z.object({
  s: z.number().finite(),                  // final_score of the last item
  d: z.number().finite().nullable(),       // distance_km of the last item (null when no location)
  i: z.string().regex(/^\d{1,18}$/),       // id of the last item
  t: z.string().datetime(),                // time anchor frozen on the first page
  h: z.string().regex(/^[0-9a-f]{16}$/),   // fingerprint of the search it belongs to
});

class BadRequest extends Error {}

const encodeCursor = (c) => Buffer.from(JSON.stringify(c)).toString('base64url');
function decodeCursor(raw) {
  try {
    return cursorSchema.parse(JSON.parse(Buffer.from(raw, 'base64url').toString('utf8')));
  } catch {
    throw new BadRequest('Invalid cursor');
  }
}
const fingerprint = (f) =>
  crypto.createHash('sha1')
    .update(JSON.stringify([f.query?.toLowerCase() ?? null, f.lat ?? null, f.lng ?? null, f.radius_km]))
    .digest('hex').slice(0, 16);

// Geo engine for the proximity filter:
//   'earthdistance' (default): cube/earthdistance on pub_lat/pub_lng, GiST idx_tuition_earth.
//   'postgis': ST_DWithin on public_location, GiST idx_tuition_location. Measured ~3x faster for
//              text + location queries, because PostGIS publishes spatial selectivity statistics, so the
//              planner combines GIN and GiST with a BitmapAnd. earthdistance's operators have none: the
//              planner assumes ~300 rows from the cube test and never ANDs the two indexes.
const GEO_ENGINE = process.env.FEED_GEO_ENGINE === 'postgis' ? 'postgis' : 'earthdistance';

// ───────────────────────── ranking ─────────────────────────
// final_score = wText*text + wGeo*proximity + wFresh*freshness, each component in [0,1].
// Weights are renormalised over the components that apply to the request.
const BASE_WEIGHTS = { text: 0.5, geo: 0.35, fresh: 0.15 };
function weights(hasText, hasGeo) {
  const w = { text: hasText ? BASE_WEIGHTS.text : 0, geo: hasGeo ? BASE_WEIGHTS.geo : 0, fresh: BASE_WEIGHTS.fresh };
  const sum = w.text + w.geo + w.fresh;
  return { text: w.text / sum, geo: w.geo / sum, fresh: w.fresh / sum };
}

// Explicit column list (no SELECT *): only what the feed card needs. formatted_address,
// the exact pin and guardian_id are never selected here.
const COLS = [
  'id', 'title', 'subjects', 'class_level', 'medium', 'area_name', 'days_per_week', 'hours_per_session',
  'preferred_time', 'rate_type', 'budget_min', 'budget_max', 'monthly_min', 'monthly_max',
  'preferred_gender', 'created_at',
];

/**
 * Builds the hybrid ranking query. Every user-supplied value goes in as a bind parameter ($n);
 * only fixed fragments are concatenated, so the statement text depends on the request *shape*
 * (text? location? cursor?) and never on its content.
 */
export function buildFeedQuery(f, cursor, anchorIso, engine = GEO_ENGINE) {
  const params = [];
  const add = (v) => { params.push(v); return `$${params.length}`; };

  const hasText = f.query !== undefined;
  const hasGeo = f.lat !== undefined;
  const w = weights(hasText, hasGeo);
  const anchor = `${add(anchorIso)}::timestamptz`;

  const where = [
    `p.status = 'active'`,                 // literal: matches the partial indexes
    `p.expires_at > now()`,
    `p.created_at <= ${anchor}`,           // snapshot: posts created after the first page appear on refresh
  ];
  const inner = COLS.map((c) => `p.${c}`);
  inner.push('ROUND(p.pub_lat::numeric, 3) AS lat', 'ROUND(p.pub_lng::numeric, 3) AS lng');

  const joins = [];
  let radiusM, tsq;
  if (hasGeo) {
    radiusM = add(f.radius_km * 1000) + '::float8';
    // The distance is computed ONCE per row in a LATERAL subquery (OFFSET 0 stops the planner from
    // inlining it back into three separate calls: filter, output and score).
    if (engine === 'postgis') {
      const origin = `ST_SetSRID(ST_MakePoint(${add(f.lng)}::float8, ${add(f.lat)}::float8), 4326)::geography`;
      where.push(`ST_DWithin(p.public_location, ${origin}, ${radiusM})`);      // GiST index + exact check
      joins.push(`CROSS JOIN LATERAL (SELECT ST_Distance(p.public_location, ${origin}) AS dist_m OFFSET 0) d`);
    } else {
      const origin = `ll_to_earth(${add(f.lat)}::float8, ${add(f.lng)}::float8)`;
      const point = 'll_to_earth(p.pub_lat, p.pub_lng)';
      // 1) earth_box @> point : cheap bounding-cube test, answered by the GiST index
      // 2) earth_distance <= r : exact great-circle check that trims the cube's corners
      where.push(`earth_box(${origin}, ${radiusM}) @> ${point}`);
      where.push(`d.dist_m <= ${radiusM}`);
      joins.push(`CROSS JOIN LATERAL (SELECT earth_distance(${origin}, ${point}) AS dist_m OFFSET 0) d`);
    }
    inner.push('d.dist_m');
    inner.push('ROUND((d.dist_m / 1000.0)::numeric, 2) AS distance_km');
  }
  if (hasText) {
    const q = `${add(f.query)}::text`;
    // OR of both dictionaries: stemmed English match OR exact token match in any language
    tsq = `(websearch_to_tsquery('english', ${q}) || websearch_to_tsquery('simple', ${q}))`;
    where.push(`p.search_vector @@ ${tsq}`);                       // answered by the GIN index
    inner.push(`ts_rank(p.search_vector, ${tsq}, 32) AS text_rank`); // 32 => rank/(rank+1), in [0,1)
  }

  const textExpr = hasText ? `${add(w.text)}::float8 * s.text_rank` : '0';
  const geoExpr = hasGeo ? `${add(w.geo)}::float8 * GREATEST(0, 1 - s.dist_m / ${radiusM})` : '0';
  // Freshness uses the frozen anchor, not now(), so a score never changes while the user scrolls.
  const freshExpr = `${add(w.fresh)}::float8 * (1.0 / (1.0 + EXTRACT(EPOCH FROM (${anchor} - s.created_at)) / 604800.0))`;

  const scoredCols = [...COLS.map((c) => `s.${c}`), 's.lat', 's.lng'];
  if (hasGeo) scoredCols.push('s.distance_km');

  // Keyset predicate on the ORDER BY key. Scores/distances are ROUNDed in SQL, so equality
  // comparisons against the cursor are exact.
  let keyset = '';
  let order = 'f.final_score DESC, f.id DESC';
  if (cursor) {
    const cs = `${add(String(cursor.s))}::numeric`;
    const ci = `${add(cursor.i)}::bigint`;
    if (hasGeo) {
      const cd = `${add(String(cursor.d))}::numeric`;
      order = 'f.final_score DESC, f.distance_km ASC, f.id DESC';
      // (score DESC, distance ASC, id DESC) has mixed directions, so a single row-value
      // comparison is not possible; this is the equivalent expanded form.
      keyset = `WHERE f.final_score < ${cs}
                   OR (f.final_score = ${cs} AND f.distance_km > ${cd})
                   OR (f.final_score = ${cs} AND f.distance_km = ${cd} AND f.id < ${ci})`;
    } else {
      keyset = `WHERE (f.final_score, f.id) < (${cs}, ${ci})`;
    }
  } else if (hasGeo) {
    order = 'f.final_score DESC, f.distance_km ASC, f.id DESC';
  }

  const outCols = [...COLS.map((c) => `f.${c}`), 'f.lat', 'f.lng'];
  if (hasGeo) outCols.push('f.distance_km');
  outCols.push('f.final_score');

  const text = `
    SELECT ${outCols.join(', ')}
      FROM (
        SELECT ${scoredCols.join(', ')},
               ROUND((${textExpr} + ${geoExpr} + ${freshExpr})::numeric, 6) AS final_score
          FROM (
            SELECT ${inner.join(', ')}
              FROM tuition_posts p ${joins.join(' ')}
             WHERE ${where.join('\n               AND ')}
          ) s
      ) f
     ${keyset}
     ORDER BY ${order}
     LIMIT ${add(f.limit + 1)}`;   // one extra row tells us whether another page exists
  return { text, params };
}

// ───────────────────────── controller ─────────────────────────
export async function getGlobalMatchedFeed(req, res, next) {
  try {
    const f = feedQuerySchema.parse(req.query);
    const hash = fingerprint(f);

    let cursor = null;
    let anchorIso = new Date().toISOString();   // frozen on page 1, carried by every later cursor
    if (f.cursor) {
      cursor = decodeCursor(f.cursor);
      if (cursor.h !== hash) throw new BadRequest('Cursor does not belong to this search');
      if ((cursor.d === null) === (f.lat !== undefined)) throw new BadRequest('Invalid cursor');
      anchorIso = cursor.t;
    }

    const { text, params } = buildFeedQuery(f, cursor, anchorIso);
    const { rows } = await query(text, params);

    const hasMore = rows.length > f.limit;
    const data = hasMore ? rows.slice(0, f.limit) : rows;
    const last = data[data.length - 1];
    const nextCursor = hasMore
      ? encodeCursor({ s: last.final_score, d: last.distance_km ?? null, i: String(last.id), t: anchorIso, h: hash })
      : null;

    res.json({ success: true, count: data.length, data, nextCursor });
  } catch (err) {
    if (err instanceof ZodError) {
      return res.status(400).json({
        success: false,
        error: err.issues.map((i) => `${i.path.join('.') || 'query'}: ${i.message}`).join('; '),
      });
    }
    if (err instanceof BadRequest) return res.status(400).json({ success: false, error: err.message });
    next(err);   // DB / unexpected errors -> central handler (503 on pool exhaustion or timeout, else 500)
  }
}
