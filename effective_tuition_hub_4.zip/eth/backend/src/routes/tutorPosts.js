import { Router } from 'express';
import { z } from 'zod';
import { pool, query } from '../db.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { searchSchema, makeParams, likePattern, pointSql, meta, stripTotal } from '../utils/search.js';
import { validateId } from '../utils/ids.js';

const r = Router();
r.param('id', validateId);

const areaSchema = z.object({
  place_name: z.string().trim().min(1).max(150),
  place_id: z.string().max(300).nullish(),
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radius_km: z.number().min(0.5).max(50),
});

const createSchema = z.object({
  headline: z.string().trim().min(5).max(200),
  description: z.string().trim().max(2000).nullish(),
  subjects: z.array(z.string().trim().min(1).max(60)).min(1).max(12),
  class_levels: z.array(z.string().trim().min(1).max(50)).min(1).max(10),
  mediums: z.array(z.string().trim().max(50)).min(1).max(3).default(['Bangla Medium']),
  online_available: z.boolean().default(false),
  days_per_week_min: z.number().int().min(1).max(7),
  days_per_week_max: z.number().int().min(1).max(7),
  hours_per_session_min: z.number().min(0.5).max(12),
  hours_per_session_max: z.number().min(0.5).max(12),
  rate_type: z.enum(['hourly', 'weekly', 'monthly']),
  rate_min: z.number().min(0),
  rate_max: z.number().min(0),
  areas: z.array(areaSchema).min(1).max(5),
}).refine((d) => d.days_per_week_max >= d.days_per_week_min, { message: 'days max < min', path: ['days_per_week_max'] })
  .refine((d) => d.hours_per_session_max >= d.hours_per_session_min, { message: 'hours max < min', path: ['hours_per_session_max'] })
  .refine((d) => d.rate_max >= d.rate_min, { message: 'rate_max must be >= rate_min', path: ['rate_max'] });

// ── Create availability post (tutor) — post + teaching areas in one transaction ──
r.post('/', requireAuth, requireRole('tutor'), async (req, res) => {
  const d = createSchema.parse(req.body);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: [post] } = await client.query(
      `INSERT INTO tutor_availability_posts
         (tutor_id, headline, description, subjects, class_levels, mediums, online_available,
          days_per_week_min, days_per_week_max, hours_per_session_min, hours_per_session_max,
          rate_type, rate_min, rate_max)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
       RETURNING id, status, expires_at, monthly_min, monthly_max`,
      [req.user.id, d.headline, d.description ?? null, d.subjects, d.class_levels, d.mediums,
       d.online_available, d.days_per_week_min, d.days_per_week_max, d.hours_per_session_min,
       d.hours_per_session_max, d.rate_type, d.rate_min, d.rate_max]);
    for (const a of d.areas) {
      await client.query(
        `INSERT INTO tutor_teaching_areas (availability_post_id, place_name, place_id, center, radius_km)
         VALUES ($1,$2,$3, ST_SetSRID(ST_MakePoint($4::float8,$5::float8),4326)::geography, $6)`,
        [post.id, a.place_name, a.place_id ?? null, a.lng, a.lat, a.radius_km]);
    }
    await client.query('COMMIT');
    res.status(201).json(post);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
});

const ORDER = {
  newest: 'a.created_at DESC',
  distance: 'distance_km ASC, a.created_at DESC',
  budget_low: 'a.monthly_min ASC, a.created_at DESC',
  budget_high: 'a.monthly_max DESC, a.created_at DESC',
};

// ── Search tutors (public; used by guardians) ──
// Location rule: a tutor matches when ANY of their teaching areas' radius covers the
// searched point (i.e. the tutor is willing to travel to that location).
r.get('/', async (req, res) => {
  const f = searchSchema.parse(req.query);
  const P = makeParams();
  const hasGeo = f.lat !== undefined;
  const pt = hasGeo ? pointSql(P, f.lat, f.lng) : null;
  const where = [`a.status = 'active'`, `a.expires_at > now()`];

  if (hasGeo) {
    // ST_DWithin with the 50 km max radius uses the GiST index; exact per-area radius refines it.
    // PRIVACY: uses the fuzzed public_center, never the tutor's exact area centre.
    where.push(`EXISTS (SELECT 1 FROM tutor_teaching_areas ta
                         WHERE ta.availability_post_id = a.id
                           AND ST_DWithin(ta.public_center, ${pt}, 50000)
                           AND ST_Distance(ta.public_center, ${pt}) <= ta.radius_km * 1000)`);
  }
  if (f.subject) where.push(`a.subjects && ${P.add(f.subject)}::text[]`);
  if (f.class_level) where.push(`a.class_levels && ${P.add(f.class_level)}::text[]`);
  if (f.rate_type) where.push(`a.rate_type = ${P.add(f.rate_type)}::rate_type`);
  if (f.q) {
    const k = P.add(likePattern(f.q));
    where.push(`(a.headline ILIKE ${k} OR u.name ILIKE ${k}
                 OR EXISTS (SELECT 1 FROM unnest(a.subjects) s WHERE s ILIKE ${k})
                 OR EXISTS (SELECT 1 FROM tutor_teaching_areas ta WHERE ta.availability_post_id = a.id AND ta.place_name ILIKE ${k}))`);
  }
  if (f.budget_min !== undefined) where.push(`a.monthly_max >= ${P.add(f.budget_min)}::numeric`);
  if (f.budget_max !== undefined) where.push(`a.monthly_min <= ${P.add(f.budget_max)}::numeric`);
  // Ranges overlap: tutor's willing range vs. the guardian's wanted range
  if (f.days_min !== undefined) where.push(`a.days_per_week_max >= ${P.add(f.days_min)}::int`);
  if (f.days_max !== undefined) where.push(`a.days_per_week_min <= ${P.add(f.days_max)}::int`);
  if (f.hours_min !== undefined) where.push(`a.hours_per_session_max >= ${P.add(f.hours_min)}::numeric`);
  if (f.hours_max !== undefined) where.push(`a.hours_per_session_min <= ${P.add(f.hours_max)}::numeric`);
  if (f.gender && f.gender !== 'any') where.push(`u.gender = ${P.add(f.gender)}::user_gender`);

  const sort = f.sort === 'distance' && !hasGeo ? 'newest' : f.sort;
  const limit = P.add(f.limit);
  const offset = P.add((f.page - 1) * f.limit);

  const { rows } = await query(
    `SELECT a.id, a.headline, a.subjects, a.class_levels, a.mediums, a.online_available,
            a.days_per_week_min, a.days_per_week_max, a.hours_per_session_min, a.hours_per_session_max,
            a.rate_type, a.rate_min, a.rate_max, a.monthly_min, a.monthly_max, a.created_at,
            u.name AS tutor_name, u.is_verified,
            tp.institution, tp.qualification, tp.experience_years, tp.profile_picture_url, tp.nid_verified,
            (SELECT COALESCE(json_agg(json_build_object(
                      'place_name', ta.place_name,
                      'lat', ROUND(ST_Y(ta.public_center::geometry)::numeric, 3),
                      'lng', ROUND(ST_X(ta.public_center::geometry)::numeric, 3),
                      'radius_km', ta.radius_km)), '[]')
               FROM tutor_teaching_areas ta WHERE ta.availability_post_id = a.id) AS areas
            ${hasGeo ? `, (SELECT ROUND((MIN(ST_Distance(ta.public_center, ${pt})) / 1000)::numeric, 1)
                             FROM tutor_teaching_areas ta WHERE ta.availability_post_id = a.id) AS distance_km` : ''},
            COUNT(*) OVER() AS total
       FROM tutor_availability_posts a
       JOIN users u ON u.id = a.tutor_id
       LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
      WHERE ${where.join(' AND ')}
      ORDER BY ${ORDER[sort]}
      LIMIT ${limit} OFFSET ${offset}`,
    P.values);

  res.json({ data: stripTotal(rows), meta: meta(rows, f) });
});

r.get('/mine', requireAuth, requireRole('tutor'), async (req, res) => {
  const { rows } = await query(
    `SELECT a.*, (SELECT COALESCE(json_agg(json_build_object(
              'id', ta.id, 'place_name', ta.place_name,
              'lat', ST_Y(ta.center::geometry), 'lng', ST_X(ta.center::geometry),
              'radius_km', ta.radius_km)), '[]')
            FROM tutor_teaching_areas ta WHERE ta.availability_post_id = a.id) AS areas
       FROM tutor_availability_posts a WHERE a.tutor_id = $1 ORDER BY a.created_at DESC`, [req.user.id]);
  res.json({ data: rows });
});

r.patch('/:id/status', requireAuth, requireRole('tutor'), async (req, res) => {
  const { status } = z.object({ status: z.enum(['active', 'cancelled']) }).parse(req.body);
  // 'pending' posts are held for moderation; re-activating starts a fresh 90-day window
  const { rowCount } = await query(
    `UPDATE tutor_availability_posts
        SET status = $1::post_status,
            expires_at = CASE WHEN $1::post_status = 'active' AND (status <> 'active' OR expires_at <= now())
                              THEN now() + INTERVAL '90 days' ELSE expires_at END
      WHERE id = $2 AND tutor_id = $3 AND status <> 'pending'`,
    [status, req.params.id, req.user.id]);
  if (!rowCount) return res.status(404).json({ error: 'Post not found' });
  res.json({ ok: true });
});

export default r;
