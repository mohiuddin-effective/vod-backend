import { Router } from 'express';
import { getGlobalMatchedFeed } from '../controllers/feedController.js';

const r = Router();
r.get('/', getGlobalMatchedFeed);   // public: tutors browse tuition requests
export default r;
