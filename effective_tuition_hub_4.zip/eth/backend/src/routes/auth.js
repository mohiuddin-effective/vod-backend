import { Router } from 'express';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool, query } from '../db.js';

const r = Router();
// Compared against when the email is unknown, so login takes the same time either way.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);
const sign = (u) => jwt.sign({ id: u.id, role: u.role }, process.env.JWT_SECRET, { expiresIn: '30d' });

r.post('/register', async (req, res) => {
  const d = z.object({
    name: z.string().trim().min(2).max(100),
    email: z.string().email().toLowerCase(),
    phone: z.string().trim().min(7).max(20),
    password: z.string().min(8).max(100),
    role: z.enum(['tutor', 'guardian', 'student']),
    gender: z.enum(['male', 'female', 'other']).optional(),
  }).parse(req.body);

  const hash = await bcrypt.hash(d.password, 12);
  // user + tutor profile are created together or not at all
  const client = await pool.connect();
  let u;
  try {
    await client.query('BEGIN');
    ({ rows: [u] } = await client.query(
      `INSERT INTO users (name, email, phone, password_hash, role, gender)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, name, email, role`,
      [d.name, d.email, d.phone, hash, d.role, d.gender ?? null]));
    if (u.role === 'tutor') await client.query('INSERT INTO tutor_profiles (user_id) VALUES ($1)', [u.id]);
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
  res.status(201).json({ token: sign(u), user: u });
});

r.post('/login', async (req, res) => {
  const d = z.object({ email: z.string().email().toLowerCase(), password: z.string().min(1) }).parse(req.body);
  const { rows: [u] } = await query(
    'SELECT id, name, email, role, password_hash FROM users WHERE email = $1', [d.email]);
  const ok = await bcrypt.compare(d.password, u?.password_hash ?? DUMMY_HASH);
  if (!u || !ok) return res.status(401).json({ error: 'Invalid email or password' });
  const { password_hash, ...user } = u;
  res.json({ token: sign(user), user });
});

export default r;
