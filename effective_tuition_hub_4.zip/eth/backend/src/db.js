import 'dotenv/config';
import pg from 'pg';

// Return BIGINT and NUMERIC as JS numbers (instead of strings) so the app gets clean JSON.
pg.types.setTypeParser(20, (v) => parseInt(v, 10));
pg.types.setTypeParser(1700, (v) => parseFloat(v));

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  // PG_POOL_MAX: keep (instances x max) below Postgres max_connections (default 100),
  // or put PgBouncer (transaction mode) in front when you run many API instances.
  max: Number(process.env.PG_POOL_MAX) || 20,
  idleTimeoutMillis: 30_000,        // close clients idle for 30 s
  connectionTimeoutMillis: 2_000,   // fail fast (-> HTTP 503) instead of queueing forever when saturated
  maxUses: 7_500,                   // recycle a connection after 7.5k queries (bounds server-side memory bloat)
  statement_timeout: 10_000,        // server cancels any query running > 10 s (error code 57014)
  application_name: 'eth-api',      // shows up in pg_stat_activity
});

// An idle client can error (DB restart, network drop, failover). Without a listener Node would
// crash with an unhandled 'error' event. pg removes the broken client from the pool itself.
pool.on('error', (err) => console.error('[pg] idle client error:', err.message));

export const query = (text, params) => pool.query(text, params);
