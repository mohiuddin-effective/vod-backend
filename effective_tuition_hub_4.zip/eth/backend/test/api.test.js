// Integration tests: spawns the API against a REAL Postgres+PostGIS database.
//   createdb eth_test && psql eth_test -f ../database/schema.sql
//   TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/eth_test npm test
// WARNING: truncates all tables in the target database.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import pg from 'pg';

const DB = process.env.TEST_DATABASE_URL;
if (!DB) throw new Error('Set TEST_DATABASE_URL (a throw-away database!)');
const PORT = 4300 + Math.floor(Math.random() * 500);
const BASE = `http://127.0.0.1:${PORT}/api`;
const pool = new pg.Pool({ connectionString: DB });
let server;

const EXACT = { lat: 23.75, lng: 90.39 };
const metres = (a, b) => {
  const R = 6371000, rad = (x) => (x * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

async function api(method, path, { token, body, headers = {}, raw } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: raw ?? (body ? JSON.stringify(body) : undefined),
  });
  let json = null;
  try { json = await res.json(); } catch { /* non-JSON */ }
  return { status: res.status, json, type: res.headers.get('content-type') || '' };
}

const reg = async (name, role, gender, n) => (await api('POST', '/auth/register', {
  body: { name, email: `${name.toLowerCase()}${n}@t.test`, phone: `0170000${String(n).padStart(4, '0')}`, password: 'password123', role, gender },
})).json;

const postBody = (over = {}) => ({
  title: 'Need Class 9 Math tutor', subjects: ['General Math'], class_level: 'Class 9',
  lat: EXACT.lat, lng: EXACT.lng, formatted_address: 'House 1, Road 2', area_name: 'Dhanmondi',
  days_per_week: 3, hours_per_session: 1.5, rate_type: 'monthly', budget_min: 4000, budget_max: 6000, ...over,
});

let guardian, maleTutor, femaleTutor, noGenderTutor;

before(async () => {
  await pool.query('TRUNCATE users RESTART IDENTITY CASCADE');
  server = spawn('node', ['src/server.js'], {
    env: { ...process.env, PORT: String(PORT), DATABASE_URL: DB, JWT_SECRET: 'test-secret', TRUST_PROXY: '1',
           RATE_AUTH_MAX: '20', EXPIRY_SWEEP_MS: '400' },
    stdio: 'inherit',
  });
  for (let i = 0; i < 50; i++) { try { await fetch(`http://127.0.0.1:${PORT}/health`); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
  guardian = await reg('Guardian', 'guardian', 'female', 1);
  maleTutor = await reg('Mtutor', 'tutor', 'male', 2);
  femaleTutor = await reg('Ftutor', 'tutor', 'female', 3);
  noGenderTutor = await reg('Ntutor', 'tutor', undefined, 4);
});
after(async () => { server?.kill(); await pool.end(); });

// ── item 6 ──
test('malformed JSON body -> 400 (not 500)', async () => {
  const r = await api('POST', '/auth/login', { raw: '{bad' });
  assert.equal(r.status, 400);
  assert.ok(r.json?.error);
});
test('non-numeric / oversized id -> 4xx JSON, never 500', async () => {
  for (const id of ['abc', '99999999999999999999999']) {
    const r = await api('GET', `/tuition-posts/${id}`);
    assert.ok([400, 404].includes(r.status), `id=${id} gave ${r.status}`);
    assert.ok(r.json?.error);
  }
});

// ── item 9 ──
test('registering a tutor creates user + profile together', async () => {
  const { rows } = await pool.query(
    `SELECT (SELECT COUNT(*) FROM tutor_profiles WHERE user_id = u.id)::int AS n FROM users u WHERE role = 'tutor'`);
  assert.equal(rows.length, 3);
  assert.ok(rows.every((r) => r.n === 1));
});

// ── item 1 ──
let post;
test('public search never exposes the exact pin or exact distance', async () => {
  const c = await api('POST', '/tuition-posts', { token: guardian.token, body: postBody({ preferred_gender: 'female' }) });
  assert.equal(c.status, 201);
  post = c.json;

  const q = `/tuition-posts?lat=${EXACT.lat}&lng=${EXACT.lng}&radius_km=1&sort=distance`;
  const r = await api('GET', q);
  assert.equal(r.status, 200);
  const item = r.json.data.find((x) => x.id === post.id);
  assert.ok(item, 'post should still be found by a search centred on it');
  assert.ok(metres(EXACT, item) > 50, `public coords too close to exact (${metres(EXACT, item).toFixed(0)} m)`);
  assert.ok(item.distance_km >= 0.1, `distance from the exact point must not be ~0 (got ${item.distance_km})`);

  // stable: repeated queries cannot be averaged to cancel noise
  const again = (await api('GET', q)).json.data.find((x) => x.id === post.id);
  assert.deepEqual([again.lat, again.lng, again.distance_km], [item.lat, item.lng, item.distance_km]);

  // owner still sees the exact pin
  const mine = (await api('GET', '/tuition-posts/mine', { token: guardian.token })).json.data[0];
  assert.equal(mine.lat, EXACT.lat);
  assert.equal(mine.lng, EXACT.lng);
});
test('public detail endpoint also hides exact pin', async () => {
  const r = await api('GET', `/tuition-posts/${post.id}`);
  assert.equal(r.status, 200);
  assert.ok(metres(EXACT, r.json) > 50);
});

// ── item 12 ──
test('apply respects guardian gender preference', async () => {
  assert.equal((await api('POST', `/tuition-posts/${post.id}/apply`, { token: maleTutor.token, body: {} })).status, 403);
  assert.equal((await api('POST', `/tuition-posts/${post.id}/apply`, { token: noGenderTutor.token, body: {} })).status, 403);
  assert.equal((await api('POST', `/tuition-posts/${post.id}/apply`, { token: femaleTutor.token, body: {} })).status, 201);
  assert.equal((await api('POST', `/tuition-posts/${post.id}/apply`, { token: femaleTutor.token, body: {} })).status, 409);
});

// ── items 10 + 11 ──
test('cancelled / expired / pending posts are not public and cannot be applied to', async () => {
  const mk = async () => (await api('POST', '/tuition-posts', { token: guardian.token, body: postBody() })).json.id;

  const cancelled = await mk();
  await api('PATCH', `/tuition-posts/${cancelled}/status`, { token: guardian.token, body: { status: 'cancelled' } });
  assert.equal((await api('GET', `/tuition-posts/${cancelled}`)).status, 404);

  const expired = await mk();
  await pool.query(`UPDATE tuition_posts SET expires_at = now() - interval '1 day' WHERE id = $1`, [expired]);
  assert.equal((await api('GET', `/tuition-posts/${expired}`)).status, 404);
  assert.equal((await api('POST', `/tuition-posts/${expired}/apply`, { token: maleTutor.token, body: {} })).status, 409);

  const pending = await mk();
  await pool.query(`UPDATE tuition_posts SET status = 'pending' WHERE id = $1`, [pending]);
  assert.equal((await api('GET', `/tuition-posts/${pending}`)).status, 404);
  // owner must not be able to bypass moderation
  assert.equal((await api('PATCH', `/tuition-posts/${pending}/status`, { token: guardian.token, body: { status: 'active' } })).status, 404);
});
test('background sweep marks lapsed posts expired; re-activating renews them', async () => {
  const id = (await api('POST', '/tuition-posts', { token: guardian.token, body: postBody() })).json.id;
  await pool.query(`UPDATE tuition_posts SET expires_at = now() - interval '1 hour' WHERE id = $1`, [id]);
  await new Promise((r) => setTimeout(r, 1200));
  assert.equal((await pool.query('SELECT status FROM tuition_posts WHERE id = $1', [id])).rows[0].status, 'expired');

  assert.equal((await api('PATCH', `/tuition-posts/${id}/status`, { token: guardian.token, body: { status: 'active' } })).status, 200);
  const { rows: [p] } = await pool.query(`SELECT status, expires_at > now() + interval '20 days' AS renewed FROM tuition_posts WHERE id = $1`, [id]);
  assert.equal(p.status, 'active');
  assert.equal(p.renewed, true);
  assert.equal((await api('GET', `/tuition-posts/${id}`)).status, 200);
});
test('tutor availability posts expire too', async () => {
  const body = {
    headline: 'Math tutor for HSC', subjects: ['Higher Math'], class_levels: ['HSC 1st Year'],
    days_per_week_min: 2, days_per_week_max: 4, hours_per_session_min: 1, hours_per_session_max: 2,
    rate_type: 'monthly', rate_min: 4000, rate_max: 8000,
    areas: [{ place_name: 'Dhanmondi', lat: EXACT.lat, lng: EXACT.lng, radius_km: 3 }],
  };
  const c = await api('POST', '/tutor-posts', { token: maleTutor.token, body });
  assert.equal(c.status, 201);
  const q = `/tutor-posts?lat=${EXACT.lat}&lng=${EXACT.lng}`;
  const found = (await api('GET', q)).json.data.find((x) => x.id === c.json.id);
  assert.ok(found, 'tutor post found');
  // area centre is not exposed exactly, and distance is not exact
  assert.ok(metres(EXACT, found.areas[0]) > 50);
  assert.ok(found.distance_km >= 0.1);
  await pool.query(`UPDATE tutor_availability_posts SET expires_at = now() - interval '1 day' WHERE id = $1`, [c.json.id]);
  assert.equal((await api('GET', q)).json.data.find((x) => x.id === c.json.id), undefined);
});

// ── items 7 + 8 ──
test('rate limiter answers JSON, and buckets by client IP behind a proxy', async () => {
  let last;
  for (let i = 0; i < 22; i++) last = await api('POST', '/auth/login', { body: { email: 'x@t.test', password: 'nope' }, headers: { 'x-forwarded-for': '10.9.9.1' } });
  assert.equal(last.status, 429);
  assert.match(last.type, /json/);
  assert.ok(last.json?.error);
  const other = await api('POST', '/auth/login', { body: { email: 'x@t.test', password: 'nope' }, headers: { 'x-forwarded-for': '10.9.9.2' } });
  assert.equal(other.status, 401, 'a different client IP must not share the exhausted bucket');
});
