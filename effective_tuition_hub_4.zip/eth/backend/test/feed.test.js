// Integration tests for GET /api/feed against a REAL Postgres (cube + earthdistance + PostGIS).
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import pg from 'pg';

const DB = process.env.TEST_DATABASE_URL;
if (!DB) throw new Error('Set TEST_DATABASE_URL (a throw-away database!)');
const PORT = 4800 + Math.floor(Math.random() * 500);
const BASE = `http://127.0.0.1:${PORT}/api`;
const pool = new pg.Pool({ connectionString: DB });
let server, guardianId;

const DHAKA = { lat: 23.75, lng: 90.39 };
const CHATTOGRAM = { lat: 22.34, lng: 91.83 };            // ~215 km from Dhaka

const feed = async (params) => {
  const res = await fetch(`${BASE}/feed?${new URLSearchParams(params)}`);
  return { status: res.status, json: await res.json() };
};

async function mkPost({ title, subjects = ['General Math'], where = DHAKA, address = 'House 1, Road 2',
                        description = null, status = 'active', createdAt = null }) {
  const { rows: [r] } = await pool.query(
    `INSERT INTO tuition_posts (guardian_id, title, description, subjects, class_level, area_name, formatted_address,
        location, days_per_week, hours_per_session, budget_min, budget_max, status, created_at)
     VALUES ($1,$2,$3,$4,'Class 9','Dhanmondi',$5, ST_SetSRID(ST_MakePoint($7,$6),4326)::geography,
             3,1.5,4000,6000,$8, COALESCE($9::timestamptz, now())) RETURNING id`,
    [guardianId, title, description, subjects, address, where.lat, where.lng, status, createdAt]);
  return Number(r.id);   // this test pool has no BIGINT parser (the API's pool does)
}

before(async () => {
  await pool.query('TRUNCATE users RESTART IDENTITY CASCADE');
  guardianId = (await pool.query(
    `INSERT INTO users (name,email,phone,password_hash,role) VALUES ('G','g@feed.test','01700000001','x','guardian') RETURNING id`)).rows[0].id;
  server = spawn('node', ['src/server.js'], {
    env: { ...process.env, PORT: String(PORT), DATABASE_URL: DB, JWT_SECRET: 'test-secret' }, stdio: 'inherit' });
  for (let i = 0; i < 50; i++) { try { await fetch(`http://127.0.0.1:${PORT}/health`); break; } catch { await new Promise((r) => setTimeout(r, 100)); } }
});
after(async () => { server?.kill(); await pool.end(); });

test('needs a query or a location; rejects bad input with success:false', async () => {
  for (const p of [{}, { lat: '23.7' }, { query: 'math', lat: '200', lng: '90' }, { query: 'math', limit: '0' }, { query: 'x', cursor: 'garbage' }]) {
    const r = await feed(p);
    assert.equal(r.status, 400, JSON.stringify(p));
    assert.equal(r.json.success, false);
    assert.ok(r.json.error);
  }
});

test('English dictionary: stemming; simple dictionary: exact tokens in any language', async () => {
  const phys = await mkPost({ title: 'Physics tutor needed for Class 10' });
  const bn = await mkPost({ title: 'গণিত শিক্ষক প্রয়োজন', subjects: ['গণিত'] });
  const es = await mkPost({ title: 'Profesor de matemáticas urgente', subjects: ['Math'] });

  const ids = async (q) => (await feed({ query: q })).json.data.map((d) => d.id);
  assert.deepEqual(await ids('tutoring'), [phys], '"tutoring" should stem-match "tutor"');
  assert.deepEqual(await ids('গণিত'), [bn], 'Bangla token');
  assert.deepEqual(await ids('matemáticas'), [es], 'Spanish token (no English stemming involved)');
  assert.deepEqual(await ids('chemistry'), []);
  assert.deepEqual(await ids('tutor -physics'), [], 'websearch syntax: exclusion');
});

test('privacy: the exact address is not searchable, coordinates are fuzzed', async () => {
  const id = await mkPost({ title: 'Biology help', address: 'Zebracrossing Lane 77, Block Q' });
  assert.deepEqual((await feed({ query: 'Zebracrossing' })).json.data, []);
  const hit = (await feed({ query: 'biology', lat: DHAKA.lat, lng: DHAKA.lng })).json.data.find((d) => d.id === id);
  assert.ok(hit);
  const R = 6371000, rad = (x) => (x * Math.PI) / 180;
  const m = 2 * R * Math.asin(Math.sqrt(Math.sin(rad(hit.lat - DHAKA.lat) / 2) ** 2 +
            Math.cos(rad(DHAKA.lat)) * Math.cos(rad(hit.lat)) * Math.sin(rad(hit.lng - DHAKA.lng) / 2) ** 2));
  assert.ok(m > 50, `public coords only ${m.toFixed(0)} m from the exact pin`);
  assert.ok(hit.distance_km >= 0.1);
  assert.equal('formatted_address' in hit, false);
  assert.equal('location' in hit, false);
  assert.equal('guardian_id' in hit, false);
});

test('radius filter and distance ordering', async () => {
  await pool.query('TRUNCATE tuition_posts RESTART IDENTITY CASCADE');
  const near = await mkPost({ title: 'Chemistry tutor', where: DHAKA });
  const far = await mkPost({ title: 'Chemistry tutor', where: CHATTOGRAM });
  const at = (radius_km) => feed({ query: 'chemistry', lat: DHAKA.lat, lng: DHAKA.lng, radius_km });

  assert.deepEqual((await at(50)).json.data.map((d) => d.id), [near]);
  const wide = (await at(300)).json.data;
  assert.deepEqual(wide.map((d) => d.id), [near, far], 'nearer post ranks first');
  assert.ok(wide[0].distance_km < 1 && wide[1].distance_km > 200 && wide[1].distance_km < 230);
  assert.ok(wide[0].final_score > wide[1].final_score);
  // location-only (no text) works too
  assert.equal((await feed({ lat: DHAKA.lat, lng: DHAKA.lng, radius_km: 50 })).json.count, 1);
});

test('inactive posts never appear', async () => {
  await pool.query('TRUNCATE tuition_posts RESTART IDENTITY CASCADE');
  const live = await mkPost({ title: 'English tutor' });
  await mkPost({ title: 'English tutor', status: 'cancelled' });
  const lapsed = await mkPost({ title: 'English tutor' });
  await pool.query(`UPDATE tuition_posts SET expires_at = now() - interval '1 hour' WHERE id = $1`, [lapsed]);
  assert.deepEqual((await feed({ query: 'english' })).json.data.map((d) => d.id), [live]);
});

test('keyset pagination: no gaps, no duplicates, same order as one big page (text + location)', async () => {
  await pool.query('TRUNCATE tuition_posts RESTART IDENTITY CASCADE');
  // 31 posts, varied distance and age, plus deliberate score ties (identical rows)
  for (let i = 0; i < 31; i++) {
    const where = { lat: DHAKA.lat + (i % 6) * 0.01, lng: DHAKA.lng + (i % 4) * 0.01 };
    await mkPost({ title: i % 3 ? 'Math tutor wanted' : 'Math tutor tutor tutor wanted', where,
                   createdAt: new Date(Date.now() - (i % 5) * 3600_000).toISOString() });
  }
  for (const geo of [false, true]) {
    const base = { query: 'math', ...(geo ? { lat: DHAKA.lat, lng: DHAKA.lng, radius_km: 100 } : {}) };
    const all = (await feed({ ...base, limit: 50 })).json;
    assert.equal(all.count, 31);
    assert.equal(all.nextCursor, null);

    const seen = [];
    let cursor, pages = 0;
    do {
      const r = (await feed({ ...base, limit: 7, ...(cursor ? { cursor } : {}) })).json;
      assert.equal(r.success, true);
      seen.push(...r.data.map((d) => d.id));
      cursor = r.nextCursor; pages++;
      assert.ok(pages < 10, 'pagination must terminate');
    } while (cursor);
    assert.equal(pages, 5);
    assert.deepEqual(seen, all.data.map((d) => d.id), `geo=${geo}: paged order must equal single-page order`);
    assert.equal(new Set(seen).size, 31);
  }
});

test('feed is a stable snapshot while scrolling; a refresh shows new posts', async () => {
  await pool.query('TRUNCATE tuition_posts RESTART IDENTITY CASCADE');
  for (let i = 0; i < 10; i++) await mkPost({ title: 'Science tutor' });
  const p1 = (await feed({ query: 'science', limit: 4 })).json;
  const intruder = await mkPost({ title: 'Science tutor science science' });   // would outrank everything
  const p2 = (await feed({ query: 'science', limit: 4, cursor: p1.nextCursor })).json;
  const p3 = (await feed({ query: 'science', limit: 4, cursor: p2.nextCursor })).json;
  const seen = [...p1.data, ...p2.data, ...p3.data].map((d) => d.id);
  assert.equal(seen.length, 10);
  assert.equal(new Set(seen).size, 10);
  assert.ok(!seen.includes(intruder), 'post created after page 1 must not appear mid-scroll');
  assert.ok((await feed({ query: 'science', limit: 4 })).json.data.map((d) => d.id).includes(intruder), 'but a fresh request shows it');
});

test('cursor is bound to its search and cannot be tampered with', async () => {
  await pool.query('TRUNCATE tuition_posts RESTART IDENTITY CASCADE');
  for (let i = 0; i < 5; i++) await mkPost({ title: 'History tutor' });
  const { nextCursor } = (await feed({ query: 'history', limit: 2 })).json;
  assert.ok(nextCursor);
  assert.equal((await feed({ query: 'geography', limit: 2, cursor: nextCursor })).status, 400, 'different query');
  assert.equal((await feed({ query: 'history', lat: '1', lng: '1', limit: 2, cursor: nextCursor })).status, 400, 'different location');
  const forged = Buffer.from(JSON.stringify({ s: "0'; DROP TABLE users;--", d: null, i: '1', t: new Date().toISOString(), h: 'deadbeefdeadbeef' })).toString('base64url');
  assert.equal((await feed({ query: 'history', cursor: forged })).status, 400);
  assert.equal((await feed({ query: "x'); DROP TABLE tuition_posts;--" })).status, 200, 'injection attempt is just text');
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM tuition_posts')).rows[0].n, 5);
});
