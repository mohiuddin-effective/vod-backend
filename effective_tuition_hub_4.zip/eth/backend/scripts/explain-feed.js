// Prints EXPLAIN (ANALYZE, BUFFERS) for typical feed requests, to verify index usage and latency.
//   DATABASE_URL=postgres://... node scripts/explain-feed.js
import 'dotenv/config';
import { pool } from '../src/db.js';
import { buildFeedQuery } from '../src/controllers/feedController.js';

const DHAKA = { lat: 23.81, lng: 90.41 };
const scenarios = {
  'text + location (physics, 25 km of Dhaka)': { query: 'physics', ...DHAKA, radius_km: 25, limit: 20 },
  'location only (25 km of Dhaka)':            { ...DHAKA, radius_km: 25, limit: 20 },
  'text only, no location (physics, global)':  { query: 'physics', radius_km: 50, limit: 20 },
  'rare word, no location (পদার্থবিজ্ঞান)':        { query: 'পদার্থবিজ্ঞান', radius_km: 50, limit: 20 },
};
for (const [name, f] of Object.entries(scenarios)) {
  const { text, params } = buildFeedQuery(f, null, new Date().toISOString());
  await pool.query(`EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT) ${text}`, params); // warm cache
  const { rows } = await pool.query(`EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT) ${text}`, params);
  const plan = rows.map((r) => r['QUERY PLAN']);
  const nodes = plan.filter((l) => /Bitmap|Index|Seq Scan|Sort|Limit/.test(l)).map((l) => l.trim().replace(/\s+\(cost.*?\)/, '').slice(0, 110));
  const time = plan.find((l) => /Execution Time/.test(l));
  const rowsOut = plan.find((l) => /actual time/.test(l))?.match(/rows=(\d+)/)?.[1];
  console.log(`\n== ${name}\n${time?.trim()}  (rows returned: ${rowsOut})`);
  console.log(nodes.map((n) => '   ' + n).join('\n'));
}
await pool.end();
