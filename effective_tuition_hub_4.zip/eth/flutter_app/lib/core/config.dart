class AppConfig {
  /// flutter run --dart-define=API_BASE=https://api.example.com/api --dart-define=GOOGLE_MAPS_KEY=xxxx
  static const apiBase =
      String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:4000/api');
  static const googleKey = String.fromEnvironment('GOOGLE_MAPS_KEY');
}
