const kSubjects = [
  'Bangla', 'English', 'General Math', 'Higher Math', 'Physics', 'Chemistry',
  'Biology', 'ICT', 'Accounting', 'Finance', 'Economics', 'Science', 'Arabic / Quran',
];
const kClassLevels = [
  'Class 1-5', 'Class 6-8', 'Class 9', 'Class 10',
  'HSC 1st Year', 'HSC 2nd Year', 'Admission', 'University',
];
const kMediums = ['Bangla Medium', 'English Medium', 'English Version'];
const kTimes = ['Morning', 'Afternoon', 'Evening', 'Flexible'];

enum RateType { hourly, weekly, monthly }

extension RateTypeX on RateType {
  String get label => switch (this) {
        RateType.hourly => 'Hourly',
        RateType.weekly => 'Weekly',
        RateType.monthly => 'Monthly',
      };
  String get unit => switch (this) {
        RateType.hourly => 'hr',
        RateType.weekly => 'week',
        RateType.monthly => 'month',
      };
  double get min => switch (this) {
        RateType.hourly => 100,
        RateType.weekly => 500,
        RateType.monthly => 1000,
      };
  double get max => switch (this) {
        RateType.hourly => 2000,
        RateType.weekly => 10000,
        RateType.monthly => 30000,
      };
  double get step => switch (this) {
        RateType.hourly => 50,
        RateType.weekly => 250,
        RateType.monthly => 500,
      };
}

String taka(num v) {
  final s = v.round().toString();
  return '৳${s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',')}';
}

String fmtNum(num v) => v % 1 == 0 ? v.toInt().toString() : v.toStringAsFixed(1);

String budgetText(String rateType, num min, num max) {
  final unit = switch (rateType) { 'hourly' => 'hr', 'weekly' => 'week', _ => 'month' };
  return min == max ? '${taka(min)} / $unit' : '${taka(min)} – ${taka(max)} / $unit';
}
