import 'package:flutter/material.dart';
import '../core/constants.dart';
import 'common.dart';

/// Days / hours / rate selections shared by the guardian and tutor posting screens.
class ScheduleBudget {
  RangeValues days;
  RangeValues hours;
  RateType rateType;
  RangeValues rate;
  bool fixedBudget;

  ScheduleBudget({
    required this.days,
    required this.hours,
    this.rateType = RateType.monthly,
    this.rate = const RangeValues(4000, 6000),
    this.fixedBudget = false,
  });

  /// Rough monthly equivalent (same formula as the database: ≈4.33 weeks / month).
  double get monthlyEstimate {
    final h = (hours.start + hours.end) / 2;
    final d = (days.start + days.end) / 2;
    final mid = fixedBudget ? rate.start : (rate.start + rate.end) / 2;
    return switch (rateType) {
      RateType.hourly => mid * h * d * 4.33,
      RateType.weekly => mid * 4.33,
      RateType.monthly => mid,
    };
  }
}

class ScheduleBudgetSection extends StatelessWidget {
  final ScheduleBudget value;
  final VoidCallback onChanged;

  /// true = tutor (willing range), false = guardian (single wanted value).
  final bool range;
  const ScheduleBudgetSection({
    super.key,
    required this.value,
    required this.onChanged,
    this.range = false,
  });

  @override
  Widget build(BuildContext context) {
    final v = value;
    final rt = v.rateType;
    final rateDivs = ((rt.max - rt.min) / rt.step).round();
    final daysText = range && v.days.start != v.days.end
        ? '${v.days.start.round()}–${v.days.end.round()} days / week'
        : '${v.days.start.round()} days / week';
    final hoursText = range && v.hours.start != v.hours.end
        ? '${fmtNum(v.hours.start)}–${fmtNum(v.hours.end)} hours / session'
        : '${fmtNum(v.hours.start)} hours / session';

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SectionTitle(range ? 'Days per week you can teach' : 'Days per week needed'),
      Text(daysText, style: const TextStyle(fontWeight: FontWeight.w600)),
      if (range)
        RangeSlider(
          values: v.days, min: 1, max: 7, divisions: 6,
          labels: RangeLabels('${v.days.start.round()}', '${v.days.end.round()}'),
          onChanged: (r) { v.days = r; onChanged(); },
        )
      else
        Slider(
          value: v.days.start, min: 1, max: 7, divisions: 6,
          label: '${v.days.start.round()}',
          onChanged: (x) { v.days = RangeValues(x, x); onChanged(); },
        ),

      SectionTitle(range ? 'Hours per session you can teach' : 'Hours per session'),
      Text(hoursText, style: const TextStyle(fontWeight: FontWeight.w600)),
      if (range)
        RangeSlider(
          values: v.hours, min: 0.5, max: 6, divisions: 11,
          labels: RangeLabels(fmtNum(v.hours.start), fmtNum(v.hours.end)),
          onChanged: (r) { v.hours = r; onChanged(); },
        )
      else
        Slider(
          value: v.hours.start, min: 0.5, max: 6, divisions: 11,
          label: fmtNum(v.hours.start),
          onChanged: (x) { v.hours = RangeValues(x, x); onChanged(); },
        ),

      SectionTitle(range ? 'Expected rate' : 'Budget'),
      SegmentedButton<RateType>(
        segments: [for (final t in RateType.values) ButtonSegment(value: t, label: Text(t.label))],
        selected: {rt},
        onSelectionChanged: (s) {
          final t = s.first;
          v.rateType = t;
          final span = t.max - t.min;
          double snap(double x) => (t.min + ((x - t.min) / t.step).round() * t.step);
          v.rate = RangeValues(snap(t.min + span * 0.2), snap(t.min + span * 0.4));
          if (v.fixedBudget) v.rate = RangeValues(v.rate.start, v.rate.start);
          onChanged();
        },
      ),
      const SizedBox(height: 8),
      SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: true, label: Text('Fixed amount')),
          ButtonSegment(value: false, label: Text('Range')),
        ],
        selected: {v.fixedBudget},
        onSelectionChanged: (s) {
          v.fixedBudget = s.first;
          if (v.fixedBudget) {
            v.rate = RangeValues(v.rate.start, v.rate.start);
          } else if (v.rate.end == v.rate.start) {
            v.rate = RangeValues(v.rate.start, (v.rate.start + rt.step * 4).clamp(rt.min, rt.max).toDouble());
          }
          onChanged();
        },
      ),
      const SizedBox(height: 4),
      Text(
        v.fixedBudget
            ? '${taka(v.rate.start)} / ${rt.unit}'
            : '${taka(v.rate.start)} – ${taka(v.rate.end)} / ${rt.unit}',
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      if (v.fixedBudget)
        Slider(
          value: v.rate.start.clamp(rt.min, rt.max).toDouble(), min: rt.min, max: rt.max, divisions: rateDivs,
          label: taka(v.rate.start),
          onChanged: (x) { v.rate = RangeValues(x, x); onChanged(); },
        )
      else
        RangeSlider(
          values: RangeValues(v.rate.start.clamp(rt.min, rt.max).toDouble(), v.rate.end.clamp(rt.min, rt.max).toDouble()),
          min: rt.min, max: rt.max, divisions: rateDivs,
          labels: RangeLabels(taka(v.rate.start), taka(v.rate.end)),
          onChanged: (r) { v.rate = r; onChanged(); },
        ),
      if (rt != RateType.monthly)
        Text('≈ ${taka(v.monthlyEstimate)} / month', style: Theme.of(context).textTheme.bodySmall),
    ]);
  }
}
