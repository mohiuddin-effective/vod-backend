import 'package:flutter/material.dart';
import '../core/constants.dart';

double? _d(dynamic v) => v == null ? null : (v as num).toDouble();

class TuitionCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final VoidCallback? onApply;
  const TuitionCard({super.key, required this.item, this.onApply});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dist = _d(item['distance_km']);
    final subjects = (item['subjects'] as List).join(', ');
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _Pill(item['class_level'] as String),
            const Spacer(),
            if (dist != null)
              Text('${dist.toStringAsFixed(1)} km away', style: Theme.of(context).textTheme.bodySmall),
          ]),
          const SizedBox(height: 8),
          Text(item['title'] as String, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          _Line(Icons.menu_book_outlined, subjects),
          _Line(Icons.place_outlined, (item['area_name'] as String?)?.isNotEmpty == true ? item['area_name'] as String : 'Location on map'),
          _Line(Icons.schedule,
              '${item['days_per_week']} days/week · ${fmtNum(_d(item['hours_per_session'])!)} h/session'),
          const Divider(height: 20),
          Row(children: [
            Expanded(
              child: Text(
                budgetText(item['rate_type'] as String, _d(item['budget_min'])!, _d(item['budget_max'])!),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: scheme.primary),
              ),
            ),
            if (onApply != null) FilledButton(onPressed: onApply, child: const Text('Apply')),
          ]),
        ]),
      ),
    );
  }
}

class TutorCard extends StatelessWidget {
  final Map<String, dynamic> item;
  const TutorCard({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final areas = (item['areas'] as List).cast<Map<String, dynamic>>();
    final dist = _d(item['distance_km']);
    final dMin = item['days_per_week_min'], dMax = item['days_per_week_max'];
    final hMin = _d(item['hours_per_session_min'])!, hMax = _d(item['hours_per_session_max'])!;
    final sub = [item['qualification'], item['institution']]
        .where((e) => e != null && (e as String).isNotEmpty)
        .join(' · ');
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(child: Text(((item['tutor_name'] as String).isEmpty ? '?' : (item['tutor_name'] as String)[0]).toUpperCase())),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Flexible(
                    child: Text(item['tutor_name'] as String,
                        style: const TextStyle(fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis),
                  ),
                  if (item['is_verified'] == true || item['nid_verified'] == true)
                    const Padding(
                      padding: EdgeInsets.only(left: 4),
                      child: Icon(Icons.verified, size: 16, color: Colors.blue),
                    ),
                ]),
                if (sub.isNotEmpty) Text(sub, style: Theme.of(context).textTheme.bodySmall),
              ]),
            ),
            if (dist != null) _Pill('${dist.toStringAsFixed(1)} km'),
          ]),
          const SizedBox(height: 10),
          Text(item['headline'] as String),
          const SizedBox(height: 6),
          _Line(Icons.menu_book_outlined, (item['subjects'] as List).join(', ')),
          _Line(Icons.school_outlined, (item['class_levels'] as List).join(', ')),
          _Line(Icons.place_outlined,
              areas.take(2).map((a) => '${a['place_name']} (${fmtNum(a['radius_km'] as num)} km)').join(', ') +
                  (areas.length > 2 ? ' +${areas.length - 2}' : '') +
                  (item['online_available'] == true ? ' · Online' : '')),
          _Line(Icons.schedule,
              '${dMin == dMax ? dMin : '$dMin–$dMax'} days/week · ${hMin == hMax ? fmtNum(hMin) : '${fmtNum(hMin)}–${fmtNum(hMax)}'} h/session'),
          const Divider(height: 20),
          Text(
            budgetText(item['rate_type'] as String, _d(item['rate_min'])!, _d(item['rate_max'])!),
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: scheme.primary),
          ),
        ]),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  const _Pill(this.text);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Text(text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Theme.of(context).colorScheme.onPrimaryContainer,
            )),
      );
}

class _Line extends StatelessWidget {
  final IconData icon;
  final String text;
  const _Line(this.icon, this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 16, color: Colors.grey),
          const SizedBox(width: 6),
          Expanded(child: Text(text)),
        ]),
      );
}
