import 'package:flutter/material.dart';
import '../models/models.dart';

class SectionTitle extends StatelessWidget {
  final String text;
  final String? hint;
  const SectionTitle(this.text, {super.key, this.hint});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(text,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          if (hint != null) Text(hint!, style: Theme.of(context).textTheme.bodySmall),
        ]),
      );
}

/// Multi- or single-select chip group; the parent decides what "toggle" means.
class ChipGroup extends StatelessWidget {
  final List<String> options;
  final Set<String> selected;
  final ValueChanged<String> onToggle;
  const ChipGroup({super.key, required this.options, required this.selected, required this.onToggle});

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 8,
        runSpacing: 4,
        children: options
            .map((o) => FilterChip(
                  label: Text(o),
                  selected: selected.contains(o),
                  onSelected: (_) => onToggle(o),
                ))
            .toList(),
      );
}

class LocationTile extends StatelessWidget {
  final PickedLocation? location;
  final String emptyText;
  final VoidCallback onTap;
  final VoidCallback? onClear;
  const LocationTile({
    super.key,
    required this.location,
    required this.emptyText,
    required this.onTap,
    this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    final loc = location;
    return Card(
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Icon(Icons.place_outlined, color: Theme.of(context).colorScheme.primary),
        title: Text(loc?.label ?? emptyText, maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: loc != null && loc.areaName.isNotEmpty
            ? Text(loc.address, maxLines: 1, overflow: TextOverflow.ellipsis)
            : null,
        trailing: loc != null && onClear != null
            ? IconButton(icon: const Icon(Icons.close), onPressed: onClear)
            : const Icon(Icons.chevron_right),
      ),
    );
  }
}
