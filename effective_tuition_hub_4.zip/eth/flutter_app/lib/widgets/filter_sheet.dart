import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../models/models.dart';
import '../screens/location_picker_screen.dart';
import 'common.dart';

/// Advanced filter bottom sheet. Resolves with the new filters on Apply, null on dismiss.
Future<SearchFilters?> showFilterSheet(BuildContext context, SearchFilters current) {
  return showModalBottomSheet<SearchFilters>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => FractionallySizedBox(heightFactor: 0.92, child: _FilterSheet(initial: current)),
  );
}

class _FilterSheet extends StatefulWidget {
  final SearchFilters initial;
  const _FilterSheet({required this.initial});
  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  late SearchFilters f = widget.initial.copy();
  static const _budgetFull = RangeValues(0, 30000);

  void _toggle(Set<String> s, String v) => setState(() => s.contains(v) ? s.remove(v) : s.add(v));

  Future<void> _pickLocation() async {
    final res = await Navigator.push<LocationPickResult>(
      context,
      MaterialPageRoute(builder: (_) => LocationPickerScreen(initial: f.location)),
    );
    if (res != null) setState(() => f.location = res.location);
  }

  @override
  Widget build(BuildContext context) {
    final sorts = {
      'newest': 'Newest',
      'distance': 'Nearest',
      'budget_low': 'Budget: low → high',
      'budget_high': 'Budget: high → low',
    };
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Text('Filters', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const Spacer(),
          TextButton(
            onPressed: () => setState(() => f = SearchFilters(query: f.query)),
            child: const Text('Reset'),
          ),
        ]),
      ),
      const Divider(height: 1),
      Expanded(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
          const SectionTitle('Subject'),
          ChipGroup(options: kSubjects, selected: f.subjects, onToggle: (s) => _toggle(f.subjects, s)),
          const SectionTitle('Class level'),
          ChipGroup(options: kClassLevels, selected: f.classLevels, onToggle: (c) => _toggle(f.classLevels, c)),

          const SectionTitle('Location & radius'),
          LocationTile(
            location: f.location,
            emptyText: 'Any location — pick on Google Maps',
            onTap: _pickLocation,
            onClear: () => setState(() {
              f.location = null;
              if (f.sort == 'distance') f.sort = 'newest';
            }),
          ),
          if (f.location != null) ...[
            const SizedBox(height: 8),
            Text('Within ${f.radiusKm.toStringAsFixed(1)} km', style: const TextStyle(fontWeight: FontWeight.w600)),
            Slider(
              value: f.radiusKm, min: 1, max: 50, divisions: 49,
              label: '${f.radiusKm.toStringAsFixed(0)} km',
              onChanged: (x) => setState(() => f.radiusKm = x),
            ),
          ],

          SectionTitle('Budget (monthly)', hint: 'Hourly and weekly rates are converted to a monthly equivalent.'),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(f.budget == null
                ? 'Any budget'
                : '${taka(f.budget!.start)} – ${taka(f.budget!.end)} / month'),
            value: f.budget != null,
            onChanged: (on) => setState(() => f.budget = on ? const RangeValues(3000, 10000) : null),
          ),
          if (f.budget != null)
            RangeSlider(
              values: f.budget!, min: _budgetFull.start, max: _budgetFull.end, divisions: 60,
              labels: RangeLabels(taka(f.budget!.start), taka(f.budget!.end)),
              onChanged: (r) => setState(() => f.budget = r),
            ),

          const SectionTitle('Days per week'),
          Text(f.days.start == f.days.end
              ? '${f.days.start.round()} days'
              : '${f.days.start.round()} – ${f.days.end.round()} days'),
          RangeSlider(
            values: f.days, min: 1, max: 7, divisions: 6,
            labels: RangeLabels('${f.days.start.round()}', '${f.days.end.round()}'),
            onChanged: (r) => setState(() => f.days = r),
          ),

          const SectionTitle('Duration (hours per session)'),
          Text('${fmtNum(f.hours.start)} – ${fmtNum(f.hours.end)} hours'),
          RangeSlider(
            values: f.hours, min: 0.5, max: 6, divisions: 11,
            labels: RangeLabels(fmtNum(f.hours.start), fmtNum(f.hours.end)),
            onChanged: (r) => setState(() => f.hours = r),
          ),

          const SectionTitle('Sort by'),
          Wrap(spacing: 8, children: [
            for (final e in sorts.entries)
              ChoiceChip(
                label: Text(e.value),
                selected: f.sort == e.key,
                onSelected: (e.key == 'distance' && f.location == null)
                    ? null
                    : (_) => setState(() => f.sort = e.key),
              ),
          ]),
        ]),
      ),
      SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            width: double.infinity,
            height: 48,
            child: FilledButton(
              onPressed: () => Navigator.pop(context, f),
              child: const Text('Apply filters'),
            ),
          ),
        ),
      ),
    ]);
  }
}
