import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/models.dart';
import '../services/places_service.dart';

/// Search with Google Places Autocomplete OR drag the map under the centre pin.
/// Pops with a [LocationPickResult] (location + radius when [showRadius] is true).
class LocationPickerScreen extends StatefulWidget {
  final PickedLocation? initial;
  final bool showRadius;
  final double initialRadiusKm;
  const LocationPickerScreen({
    super.key,
    this.initial,
    this.showRadius = false,
    this.initialRadiusKm = 3,
  });

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  static const _dhaka = LatLng(23.8103, 90.4125);

  final _searchCtrl = TextEditingController();
  GoogleMapController? _map;
  Timer? _debounce;
  late LatLng _center;
  late double _radius;
  PickedLocation? _picked;
  List<PlaceSuggestion> _suggestions = [];
  bool _resolving = false;

  @override
  void initState() {
    super.initState();
    _radius = widget.initialRadiusKm;
    _picked = widget.initial;
    _center = widget.initial != null ? LatLng(widget.initial!.lat, widget.initial!.lng) : _dhaka;
    if (widget.initial == null) _goToMyLocation(silent: true);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _goToMyLocation({bool silent = false}) async {
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        if (!silent && mounted) _toast('Location permission denied');
        return;
      }
      final pos = await Geolocator.getCurrentPosition();
      _center = LatLng(pos.latitude, pos.longitude);
      _map?.animateCamera(CameraUpdate.newLatLngZoom(_center, 16));
    } catch (_) {
      if (!silent && mounted) _toast('Could not get current location');
    }
  }

  void _onSearchChanged(String text) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () async {
      final s = await PlacesService.autocomplete(text);
      if (mounted) setState(() => _suggestions = s);
    });
  }

  Future<void> _selectSuggestion(PlaceSuggestion s) async {
    FocusScope.of(context).unfocus();
    setState(() {
      _suggestions = [];
      _searchCtrl.text = s.text;
    });
    final p = await PlacesService.details(s.placeId);
    if (p == null || !mounted) return;
    setState(() => _picked = p);
    _center = LatLng(p.lat, p.lng);
    _map?.animateCamera(CameraUpdate.newLatLngZoom(_center, 16));
  }

  Future<void> _onIdle() async {
    final p = _picked;
    // Camera settled on a location we already resolved (initial or chosen suggestion).
    if (p != null &&
        Geolocator.distanceBetween(p.lat, p.lng, _center.latitude, _center.longitude) < 5) {
      if (mounted) setState(() => _resolving = false);
      return;
    }
    setState(() => _resolving = true);
    final r = await PlacesService.reverse(_center.latitude, _center.longitude);
    if (!mounted) return;
    setState(() {
      _picked = r;
      _resolving = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final canConfirm = _picked != null && !_resolving;
    return Scaffold(
      appBar: AppBar(title: Text(widget.showRadius ? 'Teaching area' : 'Tuition location')),
      body: Stack(children: [
        GoogleMap(
          initialCameraPosition: CameraPosition(target: _center, zoom: 15),
          onMapCreated: (c) {
            _map = c;
            c.moveCamera(CameraUpdate.newLatLngZoom(_center, 15));
          },
          onCameraMoveStarted: () => setState(() => _resolving = true),
          onCameraMove: (pos) {
            _center = pos.target;
            if (widget.showRadius) setState(() {});
          },
          onCameraIdle: _onIdle,
          zoomControlsEnabled: false,
          myLocationButtonEnabled: false,
          mapToolbarEnabled: false,
          circles: widget.showRadius
              ? {
                  Circle(
                    circleId: const CircleId('radius'),
                    center: _center,
                    radius: _radius * 1000,
                    fillColor: Colors.teal.withAlpha(40),
                    strokeColor: Colors.teal,
                    strokeWidth: 2,
                  )
                }
              : const {},
        ),
        // Centre pin (tip sits on the map centre)
        const IgnorePointer(
          child: Center(
            child: Padding(
              padding: EdgeInsets.only(bottom: 40),
              child: Icon(Icons.location_pin, size: 44, color: Colors.red),
            ),
          ),
        ),
        // Search + suggestions
        Positioned(
          top: 12, left: 12, right: 12,
          child: Column(children: [
            Material(
              elevation: 3,
              borderRadius: BorderRadius.circular(12),
              child: TextField(
                controller: _searchCtrl,
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Search area, road or landmark',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searchCtrl.text.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.clear),
                          onPressed: () => setState(() {
                            _searchCtrl.clear();
                            _suggestions = [];
                          }),
                        ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            if (_suggestions.isNotEmpty)
              Material(
                elevation: 3,
                borderRadius: BorderRadius.circular(12),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 260),
                  child: ListView.separated(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    itemCount: _suggestions.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) => ListTile(
                      dense: true,
                      leading: const Icon(Icons.place_outlined),
                      title: Text(_suggestions[i].text, maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => _selectSuggestion(_suggestions[i]),
                    ),
                  ),
                ),
              ),
          ]),
        ),
        // Bottom confirm panel
        Positioned(
          left: 0, right: 0, bottom: 0,
          child: Material(
            elevation: 12,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    const Icon(Icons.place, color: Colors.red),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _resolving ? 'Finding address…' : (_picked?.address ?? 'Move the map to choose'),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    IconButton.filledTonal(
                      tooltip: 'My location',
                      icon: const Icon(Icons.my_location),
                      onPressed: _goToMyLocation,
                    ),
                  ]),
                  if (widget.showRadius) ...[
                    Row(children: [
                      const Text('Travel radius'),
                      Expanded(
                        child: Slider(
                          value: _radius, min: 0.5, max: 50, divisions: 99,
                          label: '${_radius.toStringAsFixed(1)} km',
                          onChanged: (x) => setState(() => _radius = x),
                        ),
                      ),
                      SizedBox(width: 56, child: Text('${_radius.toStringAsFixed(1)} km')),
                    ]),
                  ],
                  const SizedBox(height: 4),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: FilledButton(
                      onPressed: canConfirm
                          ? () => Navigator.pop(context, LocationPickResult(_picked!, _radius))
                          : null,
                      child: const Text('Confirm location'),
                    ),
                  ),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}
