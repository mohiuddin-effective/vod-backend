import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../widgets/common.dart';
import '../widgets/schedule_budget_section.dart';
import 'location_picker_screen.dart';

/// Tutor: "I offer tuition" — subjects, classes, teaching areas (with radius), schedule and rate.
class PostAvailabilityScreen extends StatefulWidget {
  const PostAvailabilityScreen({super.key});
  @override
  State<PostAvailabilityScreen> createState() => _PostAvailabilityScreenState();
}

class _PostAvailabilityScreenState extends State<PostAvailabilityScreen> {
  final _formKey = GlobalKey<FormState>();
  final _headline = TextEditingController();
  final _desc = TextEditingController();
  final Set<String> _subjects = {};
  final Set<String> _classes = {};
  final Set<String> _mediums = {kMediums.first};
  final List<TeachingArea> _areas = [];
  bool _online = false;
  final _sb = ScheduleBudget(
    days: const RangeValues(2, 5),
    hours: const RangeValues(1, 2),
    rate: const RangeValues(4000, 8000),
  );
  bool _submitting = false;

  @override
  void dispose() {
    _headline.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _editArea({int? index}) async {
    final existing = index == null ? null : _areas[index];
    final res = await Navigator.push<LocationPickResult>(
      context,
      MaterialPageRoute(
        builder: (_) => LocationPickerScreen(
          initial: existing?.location,
          showRadius: true,
          initialRadiusKm: existing?.radiusKm ?? 3,
        ),
      ),
    );
    if (res == null) return;
    setState(() {
      final area = TeachingArea(res.location, radiusKm: res.radiusKm);
      index == null ? _areas.add(area) : _areas[index] = area;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_subjects.isEmpty) return _snack('Select at least one subject');
    if (_classes.isEmpty) return _snack('Select at least one class level');
    if (_areas.isEmpty) return _snack('Add at least one teaching area');

    setState(() => _submitting = true);
    try {
      await ApiService.createTutorPost({
        'headline': _headline.text.trim(),
        'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        'subjects': _subjects.toList(),
        'class_levels': _classes.toList(),
        'mediums': _mediums.toList(),
        'online_available': _online,
        'days_per_week_min': _sb.days.start.round(),
        'days_per_week_max': _sb.days.end.round(),
        'hours_per_session_min': _sb.hours.start,
        'hours_per_session_max': _sb.hours.end,
        'rate_type': _sb.rateType.name,
        'rate_min': _sb.rate.start.round(),
        'rate_max': _sb.rate.end.round(),
        'areas': _areas.map((a) => a.toJson()).toList(),
      });
      if (!mounted) return;
      _snack('Availability posted');
      Navigator.pop(context, true);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Could not reach the server');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _toggle(Set<String> set, String v, {int max = 99, bool keepOne = false}) => setState(() {
        if (set.contains(v)) {
          if (!(keepOne && set.length == 1)) set.remove(v);
        } else if (set.length < max) {
          set.add(v);
        }
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post my availability')),
      body: Form(
        key: _formKey,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
          const SectionTitle('Headline'),
          TextFormField(
            controller: _headline,
            decoration: const InputDecoration(
              hintText: 'e.g. BUET student offering Math & Physics for HSC',
              border: OutlineInputBorder(),
            ),
            validator: (v) => (v == null || v.trim().length < 5) ? 'Enter at least 5 characters' : null,
          ),
          const SectionTitle('Subjects you teach'),
          ChipGroup(options: kSubjects, selected: _subjects, onToggle: (s) => _toggle(_subjects, s, max: 12)),
          const SectionTitle('Class levels'),
          ChipGroup(options: kClassLevels, selected: _classes, onToggle: (c) => _toggle(_classes, c, max: 10)),
          const SectionTitle('Medium'),
          ChipGroup(options: kMediums, selected: _mediums, onToggle: (m) => _toggle(_mediums, m, keepOne: true)),

          SectionTitle('Teaching areas', hint: 'Add up to 5 areas, each with how far you will travel.'),
          for (var i = 0; i < _areas.length; i++)
            Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: const Icon(Icons.radar),
                title: Text(_areas[i].location.label, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('Within ${_areas[i].radiusKm.toStringAsFixed(1)} km'),
                onTap: () => _editArea(index: i),
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => setState(() => _areas.removeAt(i)),
                ),
              ),
            ),
          if (_areas.length < 5)
            OutlinedButton.icon(
              onPressed: () => _editArea(),
              icon: const Icon(Icons.add_location_alt_outlined),
              label: const Text('Add teaching area (Google Maps)'),
            ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Also available online'),
            value: _online,
            onChanged: (v) => setState(() => _online = v),
          ),

          ScheduleBudgetSection(value: _sb, range: true, onChanged: () => setState(() {})),

          const SectionTitle('About your teaching (optional)'),
          TextFormField(
            controller: _desc,
            maxLines: 3,
            maxLength: 2000,
            decoration: const InputDecoration(
              hintText: 'Experience, teaching style, results…',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 50,
            child: FilledButton(
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Post availability'),
            ),
          ),
        ]),
      ),
    );
  }
}
