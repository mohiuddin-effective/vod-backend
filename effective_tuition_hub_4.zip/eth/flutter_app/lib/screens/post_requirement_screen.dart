import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../widgets/common.dart';
import '../widgets/schedule_budget_section.dart';
import 'location_picker_screen.dart';

/// Guardian / student: "I need a tutor".
class PostRequirementScreen extends StatefulWidget {
  const PostRequirementScreen({super.key});
  @override
  State<PostRequirementScreen> createState() => _PostRequirementScreenState();
}

class _PostRequirementScreenState extends State<PostRequirementScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final Set<String> _subjects = {};
  String? _classLevel;
  String _medium = kMediums.first;
  String? _time;
  String _gender = 'any';
  PickedLocation? _location;
  final _sb = ScheduleBudget(days: const RangeValues(3, 3), hours: const RangeValues(1.5, 1.5));
  bool _submitting = false;

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _pickLocation() async {
    final res = await Navigator.push<LocationPickResult>(
      context,
      MaterialPageRoute(builder: (_) => LocationPickerScreen(initial: _location)),
    );
    if (res != null) setState(() => _location = res.location);
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_subjects.isEmpty) return _snack('Select at least one subject');
    if (_classLevel == null) return _snack('Select a class level');
    if (_location == null) return _snack('Pick the tuition location on the map');

    setState(() => _submitting = true);
    try {
      await ApiService.createTuitionPost({
        'title': _title.text.trim(),
        'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        'subjects': _subjects.toList(),
        'class_level': _classLevel,
        'medium': _medium,
        'lat': _location!.lat,
        'lng': _location!.lng,
        'place_id': _location!.placeId,
        'formatted_address': _location!.address,
        'area_name': _location!.areaName,
        'days_per_week': _sb.days.start.round(),
        'hours_per_session': _sb.hours.start,
        'preferred_time': _time,
        'rate_type': _sb.rateType.name,
        'budget_min': _sb.rate.start.round(),
        'budget_max': _sb.rate.end.round(),
        'preferred_gender': _gender,
      });
      if (!mounted) return;
      _snack('Tuition requirement posted');
      Navigator.pop(context, true);
    } on ApiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Could not reach the server');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Post tuition requirement')),
      body: Form(
        key: _formKey,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
          const SectionTitle('Title'),
          TextFormField(
            controller: _title,
            decoration: const InputDecoration(
              hintText: 'e.g. Need Class 9 Math & ICT tutor',
              border: OutlineInputBorder(),
            ),
            validator: (v) => (v == null || v.trim().length < 5) ? 'Enter at least 5 characters' : null,
          ),
          const SectionTitle('Subjects', hint: 'Choose up to 8'),
          ChipGroup(
            options: kSubjects,
            selected: _subjects,
            onToggle: (s) => setState(() {
              if (!_subjects.remove(s) && _subjects.length < 8) _subjects.add(s);
            }),
          ),
          const SectionTitle('Class level'),
          ChipGroup(
            options: kClassLevels,
            selected: {if (_classLevel != null) _classLevel!},
            onToggle: (c) => setState(() => _classLevel = c),
          ),
          const SectionTitle('Medium'),
          ChipGroup(
            options: kMediums,
            selected: {_medium},
            onToggle: (m) => setState(() => _medium = m),
          ),
          const SectionTitle('Tuition location', hint: 'Search or drop a pin. Tutors only see the approximate area.'),
          LocationTile(
            location: _location,
            emptyText: 'Pick location on Google Maps',
            onTap: _pickLocation,
          ),
          ScheduleBudgetSection(value: _sb, onChanged: () => setState(() {})),
          const SectionTitle('Preferred time'),
          ChipGroup(
            options: kTimes,
            selected: {if (_time != null) _time!},
            onToggle: (t) => setState(() => _time = _time == t ? null : t),
          ),
          const SectionTitle('Preferred tutor gender'),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'any', label: Text('Any')),
              ButtonSegment(value: 'male', label: Text('Male')),
              ButtonSegment(value: 'female', label: Text('Female')),
            ],
            selected: {_gender},
            onSelectionChanged: (s) => setState(() => _gender = s.first),
          ),
          const SectionTitle('Details (optional)'),
          TextFormField(
            controller: _desc,
            maxLines: 3,
            maxLength: 2000,
            decoration: const InputDecoration(
              hintText: "Student's level, goals, special requirements…",
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 50,
            child: FilledButton(
              onPressed: _submitting ? null : _submit,
              child: _submitting
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Post requirement'),
            ),
          ),
        ]),
      ),
    );
  }
}
