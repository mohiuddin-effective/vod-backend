import 'package:flutter/material.dart';
import 'screens/post_availability_screen.dart';
import 'screens/post_requirement_screen.dart';
import 'screens/search_screen.dart';

void main() => runApp(const EffectiveTuitionHubApp());

class EffectiveTuitionHubApp extends StatelessWidget {
  const EffectiveTuitionHubApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Effective Tuition Hub',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _tab, children: const [SearchScreen(), _PostHub()]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
            NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'Post'),
          ],
        ),
      );
}

/// In production show only the option matching the logged-in user's role.
class _PostHub extends StatelessWidget {
  const _PostHub();

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Effective Tuition Hub',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const Text('A wing of Effective Education Hub'),
          const SizedBox(height: 20),
          _Option(
            icon: Icons.family_restroom,
            title: 'I need a tutor',
            subtitle: 'Post subject, class, location pin, schedule and budget.',
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const PostRequirementScreen())),
          ),
          _Option(
            icon: Icons.school,
            title: "I'm a tutor",
            subtitle: 'Post your subjects, teaching areas, availability and rate.',
            onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const PostAvailabilityScreen())),
          ),
        ]),
      );
}

class _Option extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;
  const _Option({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          contentPadding: const EdgeInsets.all(16),
          leading: Icon(icon, size: 32, color: Theme.of(context).colorScheme.primary),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );
}
