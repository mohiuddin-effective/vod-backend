import 'package:flutter/material.dart';

class PickedLocation {
  final double lat, lng;
  final String address;
  final String? placeId;
  final String areaName;
  const PickedLocation({
    required this.lat,
    required this.lng,
    required this.address,
    this.placeId,
    this.areaName = '',
  });

  String get label => areaName.isNotEmpty ? areaName : address;
}

class LocationPickResult {
  final PickedLocation location;
  final double radiusKm;
  const LocationPickResult(this.location, this.radiusKm);
}

class TeachingArea {
  PickedLocation location;
  double radiusKm;
  TeachingArea(this.location, {this.radiusKm = 3});

  Map<String, dynamic> toJson() => {
        'place_name': location.label,
        'place_id': location.placeId,
        'lat': location.lat,
        'lng': location.lng,
        'radius_km': double.parse(radiusKm.toStringAsFixed(1)),
      };
}

const kFullDays = RangeValues(1, 7);
const kFullHours = RangeValues(0.5, 6);

class SearchFilters {
  String query;
  Set<String> subjects;
  Set<String> classLevels;
  PickedLocation? location;
  double radiusKm;
  RangeValues? budget; // monthly-equivalent BDT; null = any
  RangeValues days;
  RangeValues hours;
  String sort; // newest | distance | budget_low | budget_high

  SearchFilters({
    this.query = '',
    Set<String>? subjects,
    Set<String>? classLevels,
    this.location,
    this.radiusKm = 5,
    this.budget,
    this.days = kFullDays,
    this.hours = kFullHours,
    this.sort = 'newest',
  })  : subjects = subjects ?? <String>{},
        classLevels = classLevels ?? <String>{};

  SearchFilters copy() => SearchFilters(
        query: query,
        subjects: {...subjects},
        classLevels: {...classLevels},
        location: location,
        radiusKm: radiusKm,
        budget: budget,
        days: days,
        hours: hours,
        sort: sort,
      );

  bool get _daysActive => days.start != kFullDays.start || days.end != kFullDays.end;
  bool get _hoursActive => hours.start != kFullHours.start || hours.end != kFullHours.end;

  int get activeCount =>
      (subjects.isNotEmpty ? 1 : 0) +
      (classLevels.isNotEmpty ? 1 : 0) +
      (location != null ? 1 : 0) +
      (budget != null ? 1 : 0) +
      (_daysActive ? 1 : 0) +
      (_hoursActive ? 1 : 0);

  Map<String, String> toQuery() => {
        if (query.trim().isNotEmpty) 'q': query.trim(),
        if (subjects.isNotEmpty) 'subject': subjects.join(','),
        if (classLevels.isNotEmpty) 'class_level': classLevels.join(','),
        if (location != null) ...{
          'lat': '${location!.lat}',
          'lng': '${location!.lng}',
          'radius_km': radiusKm.toStringAsFixed(1),
        },
        if (budget != null) ...{
          'budget_min': '${budget!.start.round()}',
          'budget_max': '${budget!.end.round()}',
        },
        if (_daysActive) ...{
          'days_min': '${days.start.round()}',
          'days_max': '${days.end.round()}',
        },
        if (_hoursActive) ...{
          'hours_min': fmtQ(hours.start),
          'hours_max': fmtQ(hours.end),
        },
        'sort': (sort == 'distance' && location == null) ? 'newest' : sort,
      };

  static String fmtQ(double v) => v.toStringAsFixed(1);
}
