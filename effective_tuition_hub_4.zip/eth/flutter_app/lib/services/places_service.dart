import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config.dart';
import '../models/models.dart';

class PlaceSuggestion {
  final String placeId, text;
  const PlaceSuggestion(this.placeId, this.text);
}

/// Google Places (New) autocomplete + details, and Geocoding API for map-pin reverse lookup.
/// Enable "Places API (New)" and "Geocoding API" in Google Cloud and restrict the key
/// (Android package + SHA-1 / iOS bundle ID). For stricter security proxy these calls via your backend.
class PlacesService {
  static Future<List<PlaceSuggestion>> autocomplete(String input, {String region = 'bd'}) async {
    if (input.trim().length < 2) return [];
    try {
      final res = await http.post(
        Uri.parse('https://places.googleapis.com/v1/places:autocomplete'),
        headers: {'Content-Type': 'application/json', 'X-Goog-Api-Key': AppConfig.googleKey},
        body: jsonEncode({
          'input': input,
          'includedRegionCodes': [region],
          'languageCode': 'en',
        }),
      );
      if (res.statusCode != 200) return [];
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      return ((data['suggestions'] ?? []) as List)
          .where((s) => s['placePrediction'] != null)
          .map((s) => PlaceSuggestion(
                s['placePrediction']['placeId'] as String,
                s['placePrediction']['text']['text'] as String,
              ))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<PickedLocation?> details(String placeId) async {
    try {
      final res = await http.get(
        Uri.parse('https://places.googleapis.com/v1/places/$placeId'),
        headers: {
          'X-Goog-Api-Key': AppConfig.googleKey,
          'X-Goog-FieldMask': 'id,formattedAddress,location,addressComponents',
        },
      );
      if (res.statusCode != 200) return null;
      final d = jsonDecode(res.body) as Map<String, dynamic>;
      final comps = ((d['addressComponents'] ?? []) as List)
          .map((c) => (name: c['longText'] as String? ?? '', types: List<String>.from(c['types'] ?? [])))
          .toList();
      return PickedLocation(
        lat: (d['location']['latitude'] as num).toDouble(),
        lng: (d['location']['longitude'] as num).toDouble(),
        address: d['formattedAddress'] as String? ?? '',
        placeId: placeId,
        areaName: _area(comps),
      );
    } catch (_) {
      return null;
    }
  }

  static Future<PickedLocation> reverse(double lat, double lng) async {
    final fallback = PickedLocation(
      lat: lat, lng: lng,
      address: '${lat.toStringAsFixed(5)}, ${lng.toStringAsFixed(5)}',
    );
    try {
      final res = await http.get(Uri.https('maps.googleapis.com', '/maps/api/geocode/json',
          {'latlng': '$lat,$lng', 'key': AppConfig.googleKey}));
      if (res.statusCode != 200) return fallback;
      final results = (jsonDecode(res.body)['results'] ?? []) as List;
      if (results.isEmpty) return fallback;
      final r = results.first as Map<String, dynamic>;
      final comps = ((r['address_components'] ?? []) as List)
          .map((c) => (name: c['long_name'] as String? ?? '', types: List<String>.from(c['types'] ?? [])))
          .toList();
      return PickedLocation(
        lat: lat, lng: lng,
        address: r['formatted_address'] as String? ?? fallback.address,
        placeId: r['place_id'] as String?,
        areaName: _area(comps),
      );
    } catch (_) {
      return fallback;
    }
  }

  static String _area(List<({String name, List<String> types})> comps) {
    for (final t in ['sublocality_level_1', 'sublocality', 'neighborhood', 'locality', 'administrative_area_level_2']) {
      for (final c in comps) {
        if (c.types.contains(t)) return c.name;
      }
    }
    return '';
  }
}
