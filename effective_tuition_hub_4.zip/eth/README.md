# Effective Tuition Hub — tutor & tuition matching app
A wing of Effective Education Hub. Flutter app · Node.js/Express API · PostgreSQL + PostGIS.

```
database/schema.sql        PostGIS schema, generated monthly-equivalent budget columns, indexes
backend/                   Express 5 API (zod validation, JWT, pg)
flutter_app/lib/           Screens, widgets, API + Google Places services
```

## 1. Database
```bash
createdb effective_tuition_hub
psql effective_tuition_hub -f database/schema.sql   # needs PostGIS installed
```
**Upgrading an existing database** (created from the original schema)? Run the migration once instead:
```bash
psql effective_tuition_hub -f database/migrations/002_hardening.sql
```
It adds the fuzzed public locations (back-filled for existing rows) and tutor-post expiry.

## 2. Backend
```bash
cd backend && cp .env.example .env   # set DATABASE_URL and JWT_SECRET
npm install && npm run dev           # http://localhost:4000
```
Behind a proxy or load balancer, also set `TRUST_PROXY` (number of hops, usually `1`) - see `.env.example`.

**Tests** (integration tests against a real PostGIS database; **they truncate all tables**, so use a throw-away DB):
```bash
createdb eth_test && psql eth_test -f ../database/schema.sql
TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/eth_test npm test
```

| Method | Endpoint | Who | Notes |
|---|---|---|---|
| POST | /api/auth/register, /api/auth/login | all | roles: tutor, guardian, student |
| POST | /api/tuition-posts | guardian/student | exact lat/lng + budget/days/hours |
| GET  | /api/tuition-posts | public | search (used by tutors); active, unexpired posts only |
| GET  | /api/tuition-posts/:id | public | 404 unless active and unexpired |
| GET  | /api/tuition-posts/mine | guardian/student | exact location + applications count |
| POST | /api/tuition-posts/:id/apply | tutor | respects the post's preferred tutor gender; 409 if inactive/expired/already applied |
| PATCH| /api/tuition-posts/:id/status | owner | active / filled / cancelled; re-activating renews the expiry; `pending` (moderation) posts can't be changed by the owner |
| POST | /api/tutor-posts | tutor | post + up to 5 teaching areas (lat/lng/radius) |
| GET  | /api/tutor-posts | public | search (used by guardians) |
| GET  | /api/tutor-posts/mine, PATCH /:id/status | tutor | |

**Search query params (both GET endpoints):**
`q, subject=Physics,ICT, class_level=Class 9,Class 10, lat, lng, radius_km (0.5–50, default 5),
budget_min, budget_max (monthly-equivalent ৳), rate_type, days_min, days_max, hours_min, hours_max,
gender, sort=newest|distance|budget_low|budget_high, page, limit`

Example: `GET /api/tuition-posts?lat=22.3569&lng=91.7832&radius_km=5&subject=Physics&budget_min=3000&budget_max=8000&days_min=2&days_max=4&sort=distance`

**How matching works**
- Tuition search: post pin within `radius_km` of the searched point (`ST_DWithin`, GiST index).
- Tutor search: a tutor matches when any of their teaching-area radii covers the searched point (i.e. they will travel there).
- Budget: hourly/weekly/monthly rates are stored with a generated monthly equivalent (≈4.33 weeks/month); the filter checks that ranges overlap.
- Days/hours: guardian posts hold one value, tutor posts hold a willing range; filters use range overlap for tutors.
- Privacy: every public query (filtering, `distance_km`, sorting, returned coordinates) uses a **fuzzed copy** of the pin, fixed at insert time and offset 150-400 m in a random direction (`public_location` / `public_center`, set by database triggers). The real pin and full address are visible to the owner only, and neither the coordinates nor the distance/radius filters can be used to triangulate it. `distance_km` is rounded to 0.1 km. Consequence: a post near the edge of a search radius may appear or drop out by a few hundred metres.
- Expiry: tuition posts live 30 days, tutor availability posts 90 days. A background sweep (every 15 min) marks lapsed posts `expired`; setting a post back to `active` starts a fresh window.

## 3. Flutter app
```bash
cd flutter_app
flutter create .          # generates android/ ios/ (keeps lib/ and pubspec.yaml)
flutter pub get
flutter run --dart-define=API_BASE=http://10.0.2.2:4000/api --dart-define=GOOGLE_MAPS_KEY=YOUR_KEY
```
Google Cloud: enable **Maps SDK for Android/iOS**, **Places API (New)**, **Geocoding API**; restrict the key.

Android — `android/app/src/main/AndroidManifest.xml` (inside `<application>`, plus permissions).
**`INTERNET` is required** - `flutter create` only adds it to the debug manifest, so without it release builds cannot reach the API:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<meta-data android:name="com.google.android.geo.API_KEY" android:value="YOUR_KEY"/>
```
iOS — `Info.plist`: add `NSLocationWhenInUseUsageDescription`; in `AppDelegate.swift` call `GMSServices.provideAPIKey("YOUR_KEY")`.

Screens: `search_screen` (tuition/tutor toggle, live search, chips, pagination) · `filter_sheet` (subject, class, map location + radius, budget, days, duration, sort) · `post_requirement_screen` (guardian) · `post_availability_screen` (tutor, multiple areas with radius) · `location_picker_screen` (Places autocomplete + draggable map pin).

## Not included yet
Login/register screens (set `ApiService.token`), chat/contact flow, push notifications, phone OTP, admin verification.

## Global matched feed - `GET /api/feed`

Public, infinite-scroll feed of tuition requests ranked by **text relevance + proximity + freshness**.

| Param | Notes |
|---|---|
| `query` | Free text (websearch syntax: `"exact phrase"`, `-exclude`, `or`). Searches title, subjects, class/medium/area, description. |
| `lat`, `lng` | Optional pair. Enables the radius filter and distance ranking. |
| `radius_km` | 1-500, default 50. |
| `limit` | 1-50, default 20. |
| `cursor` | Opaque string from the previous response's `nextCursor`. |

At least one of `query` or `lat`+`lng` is required (otherwise every live post would be scored on every page).
Response: `{ success, count, data, nextCursor }` - `nextCursor` is `null` on the last page. Errors: `{ success: false, error }`.

**Search.** `search_vector` is maintained by a trigger and indexes every text twice: `english` (stemming: "tutoring" finds "tutor") and `simple` (exact tokens in any language, e.g. Bangla). The exact `formatted_address` is never indexed. Verify your production DB locale keeps Bangla words whole:
`SELECT to_tsvector('simple','শিক্ষক');` must return **one** lexeme.

**Ranking.** `final_score = 0.5*text + 0.35*proximity + 0.15*freshness` (weights renormalised over the parts that apply), each part in [0,1]; ordered by `final_score DESC, distance_km ASC, id DESC`.

**Pagination.** Keyset, not OFFSET. The cursor carries the last item's `(score, distance, id)`, a **time anchor** frozen on page 1 (freshness decays with time, so without it scores would drift while the user scrolls and items would be skipped or repeated), and a fingerprint of the search (a cursor is rejected if `query/lat/lng/radius` differ). Posts created after page 1 appear on the next refresh, not mid-scroll.

**Geo engine** (`FEED_GEO_ENGINE`):
- `earthdistance` (default): `earth_box(...) @> ll_to_earth(pub_lat, pub_lng)` + exact `earth_distance` recheck, GiST `idx_tuition_earth`.
- `postgis`: `ST_DWithin` on `public_location`, GiST `idx_tuition_location`. **Recommended for text + location queries.** earthdistance's operators have no selectivity statistics, so the planner assumes ~300 rows from the box test and never combines the GIN and GiST indexes. PostGIS does, and the planner builds a `BitmapAnd`.

Measured on 300k live posts / 15 cities, one local Postgres 16 (laptop-class VM, warm cache; expect different absolute numbers on your hardware):

| Request | earthdistance | postgis |
|---|---|---|
| text + location (physics, 25 km, ~4.8k matches) | 176 ms | **51 ms** (BitmapAnd) |
| location only (25 km, ~42k candidates) | 622 ms | 425 ms |
| text only, common word (33k matches) | 205 ms | 226 ms |
| text only, rare word (3.4k matches) | 16 ms | 16 ms |

Cost grows with the number of *candidates* that pass the filters (each is scored; keyset removes the OFFSET skip cost but not the scoring). Keep the default radius modest, and expect broad queries on millions of posts to need a dedicated search engine.
Re-run on your data: `DATABASE_URL=... node scripts/explain-feed.js` (synthetic data: `database/perf/seed.sql`).

**Production notes.** `random_page_cost = 1.1` on SSD storage; keep (API instances x `PG_POOL_MAX`) under Postgres `max_connections` or add PgBouncer; pool exhaustion and `statement_timeout` (10 s) return `503 + Retry-After`; existing databases: run `database/migrations/003_global_feed.sql` after `002`.

