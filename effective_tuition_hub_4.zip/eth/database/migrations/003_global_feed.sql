-- Adds the global feed (full-text + earthdistance) to an EXISTING database.
--   psql "$DATABASE_URL" -f database/migrations/003_global_feed.sql
-- Requires 002_hardening.sql first (it provides public_location). On very large tables the
-- ALTER TABLE rewrites the table once (generated columns): run it in a quiet window.
BEGIN;

-- ═════════ Global feed: multi-language full-text search + earthdistance proximity ═════════
CREATE EXTENSION IF NOT EXISTS cube;
CREATE EXTENSION IF NOT EXISTS earthdistance;

-- earthdistance works on plain lat/lng columns. These are GENERATED FROM THE FUZZED public_location
-- (never the exact pin), so everything indexed and ranked below is safe to expose publicly.
ALTER TABLE tuition_posts
  ADD COLUMN pub_lat       DOUBLE PRECISION GENERATED ALWAYS AS (ST_Y(public_location::geometry)) STORED,
  ADD COLUMN pub_lng       DOUBLE PRECISION GENERATED ALWAYS AS (ST_X(public_location::geometry)) STORED,
  ADD COLUMN search_vector TSVECTOR;

-- Every searchable text is indexed twice and the two vectors are concatenated:
--   'english' -> stemming + stop words  ("tutoring" matches "tutor")
--   'simple'  -> no stemming, no stop words: exact lower-cased tokens in ANY language (Bangla, Hindi, Arabic, ...)
-- Weights: A title > B subjects > C class/medium/area > D description.
-- PRIVACY: formatted_address (the exact address) is deliberately NOT indexed.
CREATE OR REPLACE FUNCTION tuition_posts_search_vector_update() RETURNS TRIGGER AS $$
DECLARE
  subj TEXT := array_to_string(NEW.subjects, ' ');
  meta TEXT := concat_ws(' ', NEW.class_level, NEW.medium, NEW.area_name);
BEGIN
  NEW.search_vector :=
       setweight(to_tsvector('english', coalesce(NEW.title, '')),       'A')
    || setweight(to_tsvector('simple',  coalesce(NEW.title, '')),       'A')
    || setweight(to_tsvector('english', coalesce(subj, '')),            'B')
    || setweight(to_tsvector('simple',  coalesce(subj, '')),            'B')
    || setweight(to_tsvector('english', coalesce(meta, '')),            'C')
    || setweight(to_tsvector('simple',  coalesce(meta, '')),            'C')
    || setweight(to_tsvector('english', coalesce(NEW.description, '')), 'D')
    || setweight(to_tsvector('simple',  coalesce(NEW.description, '')), 'D');
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tuition_search
  BEFORE INSERT OR UPDATE OF title, description, subjects, class_level, medium, area_name ON tuition_posts
  FOR EACH ROW EXECUTE FUNCTION tuition_posts_search_vector_update();

UPDATE tuition_posts SET title = title;                 -- back-fills search_vector for existing rows
ALTER TABLE tuition_posts ALTER COLUMN search_vector SET NOT NULL;

-- Partial indexes: only live posts are indexed, so filled/cancelled/expired history costs nothing.
-- The feed query repeats `status = 'active'` literally, which lets the planner use them.
CREATE INDEX idx_tuition_search ON tuition_posts USING GIN  (search_vector)                    WHERE status = 'active';
CREATE INDEX idx_tuition_earth  ON tuition_posts USING GIST (ll_to_earth(pub_lat, pub_lng))    WHERE status = 'active';

COMMIT;
