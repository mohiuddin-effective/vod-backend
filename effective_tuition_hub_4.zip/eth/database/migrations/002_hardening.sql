-- Upgrade an EXISTING Effective Tuition Hub database (created from the original schema.sql).
-- Fresh installs do not need this: schema.sql already includes everything below.
--   psql "$DATABASE_URL" -f database/migrations/002_hardening.sql
-- Safe to run once. Wrapped in a transaction.
BEGIN;

-- Privacy: fuzzed public copies of exact locations (see schema.sql for rationale)
CREATE OR REPLACE FUNCTION fuzz_point(g geography, min_m double precision DEFAULT 150,
                                      max_m double precision DEFAULT 400)
RETURNS geography LANGUAGE sql VOLATILE AS $$
  SELECT ST_Project(g, min_m + random() * (max_m - min_m), random() * 2 * pi())::geography
$$;

ALTER TABLE tuition_posts        ADD COLUMN public_location GEOGRAPHY(Point, 4326);
ALTER TABLE tutor_teaching_areas ADD COLUMN public_center   GEOGRAPHY(Point, 4326);
UPDATE tuition_posts        SET public_location = fuzz_point(location);
UPDATE tutor_teaching_areas SET public_center   = fuzz_point(center);
ALTER TABLE tuition_posts        ALTER COLUMN public_location SET NOT NULL;
ALTER TABLE tutor_teaching_areas ALTER COLUMN public_center   SET NOT NULL;

CREATE OR REPLACE FUNCTION set_public_location() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.location IS DISTINCT FROM OLD.location THEN
    NEW.public_location := fuzz_point(NEW.location);
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION set_public_center() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.center IS DISTINCT FROM OLD.center THEN
    NEW.public_center := fuzz_point(NEW.center);
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tuition_publoc BEFORE INSERT OR UPDATE OF location ON tuition_posts
  FOR EACH ROW EXECUTE FUNCTION set_public_location();
CREATE TRIGGER trg_area_pubctr    BEFORE INSERT OR UPDATE OF center   ON tutor_teaching_areas
  FOR EACH ROW EXECUTE FUNCTION set_public_center();

DROP INDEX IF EXISTS idx_tuition_location;
DROP INDEX IF EXISTS idx_areas_center;
CREATE INDEX idx_tuition_location ON tuition_posts USING GIST (public_location);
CREATE INDEX idx_areas_center     ON tutor_teaching_areas USING GIST (public_center);

-- Expiry for tutor availability posts (existing ones get 90 days from now)
ALTER TABLE tutor_availability_posts
  ADD COLUMN expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '90 days');

CREATE INDEX idx_tuition_expiry   ON tuition_posts (expires_at)            WHERE status = 'active';
CREATE INDEX idx_tutorpost_expiry ON tutor_availability_posts (expires_at) WHERE status = 'active';

COMMIT;
