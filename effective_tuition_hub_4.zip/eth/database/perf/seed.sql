-- Synthetic load: 300k live posts around 15 world cities (Dhaka-heavy), 10% Bangla titles.
-- Usage: createdb eth_perf && psql eth_perf -f database/schema.sql && psql eth_perf -f database/perf/seed.sql
INSERT INTO users (name,email,phone,password_hash,role) VALUES ('Seed','seed@perf.test','0100000000','x','guardian');

WITH cities(lat,lng,w) AS (VALUES
  (23.81,90.41,30),(22.36,91.78,8),(24.90,91.87,4),(51.51,-0.13,8),(40.71,-74.01,8),(25.20,55.27,8),
  (1.35,103.82,5),(43.65,-79.38,5),(-33.87,151.21,4),(19.08,72.88,5),(24.86,67.01,4),(3.14,101.69,4),
  (40.42,-3.70,3),(52.52,13.40,3),(35.68,139.69,3)),
pick AS (SELECT lat,lng,sum(w) OVER (ORDER BY lat,lng) AS cum, sum(w) OVER () AS total FROM cities),
subj(n,name,bn) AS (VALUES (0,'Math','গণিত'),(1,'Physics','পদার্থবিজ্ঞান'),(2,'Chemistry','রসায়ন'),(3,'Biology','জীববিজ্ঞান'),
  (4,'English','ইংরেজি'),(5,'ICT','আইসিটি'),(6,'Accounting','হিসাববিজ্ঞান'),(7,'Economics','অর্থনীতি'),
  (8,'Bangla','বাংলা'),(9,'Arabic','আরবি')),
gen AS (SELECT g, random()*(SELECT max(total) FROM pick) AS r, (random()*9)::int AS s, random() AS bn, random() AS jx, random() AS jy FROM generate_series(1,300000) g)
INSERT INTO tuition_posts (guardian_id,title,description,subjects,class_level,area_name,formatted_address,location,
                           days_per_week,hours_per_session,budget_min,budget_max,created_at)
SELECT 1,
       CASE WHEN gen.bn < 0.1 THEN subj.bn || ' শিক্ষক প্রয়োজন, ' || 'Class ' || (5 + (gen.g % 8))
            ELSE subj.name || ' tutor needed for Class ' || (5 + (gen.g % 8)) END,
       'Looking for an experienced tutor, ' || subj.name || ' lessons ' || (1 + gen.g % 5) || ' days a week.',
       ARRAY[subj.name], 'Class ' || (5 + (gen.g % 8)), 'Area ' || (gen.g % 400), 'Private address ' || gen.g,
       ST_SetSRID(ST_MakePoint(c.lng + (gen.jy-0.5)*0.6, c.lat + (gen.jx-0.5)*0.6),4326)::geography,
       1 + gen.g % 6, 1.5, 2000 + (gen.g % 30)*100, 4000 + (gen.g % 30)*100,
       now() - (random()*60) * interval '1 day'
  FROM gen
  JOIN subj ON subj.n = gen.s
  JOIN LATERAL (SELECT lat,lng FROM pick WHERE cum >= gen.r ORDER BY cum LIMIT 1) c ON true;
ANALYZE tuition_posts;
