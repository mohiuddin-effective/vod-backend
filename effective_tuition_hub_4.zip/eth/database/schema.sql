-- Effective Tuition Hub — PostgreSQL 14+ with PostGIS 3+
-- Run: psql "$DATABASE_URL" -f schema.sql
BEGIN;

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ───────── Enums ─────────
CREATE TYPE user_role          AS ENUM ('tutor','guardian','student','admin');
CREATE TYPE user_gender        AS ENUM ('male','female','other');
CREATE TYPE gender_pref        AS ENUM ('male','female','any');
CREATE TYPE post_status        AS ENUM ('active','pending','filled','cancelled','expired');
CREATE TYPE rate_type          AS ENUM ('hourly','weekly','monthly');
CREATE TYPE application_status AS ENUM ('pending','shortlisted','accepted','rejected','withdrawn');

-- Normalises any rate to a monthly equivalent so hourly/weekly/monthly posts
-- can be compared by one budget filter (≈4.33 weeks per month).
CREATE OR REPLACE FUNCTION monthly_equiv(rt rate_type, amount NUMERIC, hrs NUMERIC, dpw NUMERIC)
RETURNS NUMERIC LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT ROUND(CASE rt
    WHEN 'hourly'  THEN amount * hrs * dpw * 4.33
    WHEN 'weekly'  THEN amount * 4.33
    ELSE amount END, 2)
$$;

-- Privacy: every public query uses a *fuzzed* copy of a private point (fixed at
-- insert time, 150-400 m away in a random direction). Because the offset is stored,
-- repeated queries cannot average the noise away, and ST_DWithin / ST_Distance on the
-- public copy cannot be used to triangulate the real address. Owners see the exact pin.
CREATE OR REPLACE FUNCTION fuzz_point(g geography, min_m double precision DEFAULT 150,
                                      max_m double precision DEFAULT 400)
RETURNS geography LANGUAGE sql VOLATILE AS $$
  SELECT ST_Project(g, min_m + random() * (max_m - min_m), random() * 2 * pi())::geography
$$;

-- ───────── Users ─────────
CREATE TABLE users (
  id            BIGSERIAL PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  phone         VARCHAR(20)  UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          user_role NOT NULL DEFAULT 'guardian',
  gender        user_gender,
  is_verified   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ───────── Tutor profiles (who the tutor is) ─────────
CREATE TABLE tutor_profiles (
  id                  BIGSERIAL PRIMARY KEY,
  user_id             BIGINT UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bio                 TEXT,
  institution         VARCHAR(150),
  department          VARCHAR(100),
  qualification       VARCHAR(100),
  experience_years    SMALLINT NOT NULL DEFAULT 0,
  profile_picture_url TEXT,
  nid_verified        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ───────── Tuition posts (guardian/student: "I need a tutor") ─────────
CREATE TABLE tuition_posts (
  id                BIGSERIAL PRIMARY KEY,
  guardian_id       BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title             VARCHAR(200) NOT NULL,
  description       TEXT,
  subjects          TEXT[] NOT NULL CHECK (cardinality(subjects) BETWEEN 1 AND 8),
  class_level       VARCHAR(50) NOT NULL,
  medium            VARCHAR(50) NOT NULL DEFAULT 'Bangla Medium',

  -- Location (exact pin chosen with Google Maps / Places)
  location          GEOGRAPHY(Point, 4326) NOT NULL,   -- PRIVATE exact pin (owner only)
  public_location   GEOGRAPHY(Point, 4326) NOT NULL,   -- fuzzed copy, set by trigger; use for ALL public queries
  place_id          TEXT,
  formatted_address TEXT,          -- private: returned to the owner only
  area_name         VARCHAR(120),  -- public: neighbourhood / district label

  -- Schedule & duration
  days_per_week     SMALLINT NOT NULL CHECK (days_per_week BETWEEN 1 AND 7),
  hours_per_session NUMERIC(3,1) NOT NULL CHECK (hours_per_session > 0 AND hours_per_session <= 12),
  preferred_time    VARCHAR(30),
  start_date        DATE,

  -- Budget (fixed amount => budget_min = budget_max)
  rate_type         rate_type NOT NULL DEFAULT 'monthly',
  budget_min        NUMERIC(10,2) NOT NULL CHECK (budget_min >= 0),
  budget_max        NUMERIC(10,2) NOT NULL,
  monthly_min       NUMERIC(10,2) GENERATED ALWAYS AS
                    (monthly_equiv(rate_type, budget_min, hours_per_session, days_per_week)) STORED,
  monthly_max       NUMERIC(10,2) GENERATED ALWAYS AS
                    (monthly_equiv(rate_type, budget_max, hours_per_session, days_per_week)) STORED,

  preferred_gender  gender_pref NOT NULL DEFAULT 'any',
  status            post_status NOT NULL DEFAULT 'active',
  expires_at        TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '30 days'),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (budget_max >= budget_min)
);

-- ───────── Tutor availability posts (tutor: "I offer tuition") ─────────
CREATE TABLE tutor_availability_posts (
  id                    BIGSERIAL PRIMARY KEY,
  tutor_id              BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  headline              VARCHAR(200) NOT NULL,
  description           TEXT,
  subjects              TEXT[] NOT NULL CHECK (cardinality(subjects) BETWEEN 1 AND 12),
  class_levels          TEXT[] NOT NULL CHECK (cardinality(class_levels) BETWEEN 1 AND 10),
  mediums               TEXT[] NOT NULL DEFAULT ARRAY['Bangla Medium'],
  online_available      BOOLEAN NOT NULL DEFAULT FALSE,

  -- Willing range of days/week and hours/session
  days_per_week_min     SMALLINT NOT NULL CHECK (days_per_week_min BETWEEN 1 AND 7),
  days_per_week_max     SMALLINT NOT NULL CHECK (days_per_week_max BETWEEN 1 AND 7),
  hours_per_session_min NUMERIC(3,1) NOT NULL CHECK (hours_per_session_min > 0),
  hours_per_session_max NUMERIC(3,1) NOT NULL CHECK (hours_per_session_max <= 12),

  -- Expected rate (fixed => rate_min = rate_max)
  rate_type             rate_type NOT NULL DEFAULT 'monthly',
  rate_min              NUMERIC(10,2) NOT NULL CHECK (rate_min >= 0),
  rate_max              NUMERIC(10,2) NOT NULL,
  monthly_min           NUMERIC(10,2) GENERATED ALWAYS AS (monthly_equiv(rate_type, rate_min,
                          (hours_per_session_min + hours_per_session_max) / 2,
                          (days_per_week_min + days_per_week_max) / 2.0)) STORED,
  monthly_max           NUMERIC(10,2) GENERATED ALWAYS AS (monthly_equiv(rate_type, rate_max,
                          (hours_per_session_min + hours_per_session_max) / 2,
                          (days_per_week_min + days_per_week_max) / 2.0)) STORED,

  status                post_status NOT NULL DEFAULT 'active',
  expires_at            TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '90 days'),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (days_per_week_max >= days_per_week_min),
  CHECK (hours_per_session_max >= hours_per_session_min),
  CHECK (rate_max >= rate_min)
);

-- A tutor can cover several areas, each with its own travel radius
CREATE TABLE tutor_teaching_areas (
  id                    BIGSERIAL PRIMARY KEY,
  availability_post_id  BIGINT NOT NULL REFERENCES tutor_availability_posts(id) ON DELETE CASCADE,
  place_name            VARCHAR(150) NOT NULL,
  place_id              TEXT,
  center                GEOGRAPHY(Point, 4326) NOT NULL,   -- PRIVATE exact centre (owner only)
  public_center         GEOGRAPHY(Point, 4326) NOT NULL,   -- fuzzed copy, set by trigger
  radius_km             NUMERIC(4,1) NOT NULL DEFAULT 3 CHECK (radius_km BETWEEN 0.5 AND 50)
);

-- ───────── Applications (tutor → tuition post) ─────────
CREATE TABLE tuition_applications (
  id         BIGSERIAL PRIMARY KEY,
  post_id    BIGINT NOT NULL REFERENCES tuition_posts(id) ON DELETE CASCADE,
  tutor_id   BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  cover_note TEXT,
  status     application_status NOT NULL DEFAULT 'pending',
  applied_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (post_id, tutor_id)
);

-- ───────── Indexes ─────────
-- Geo (radius search uses ST_DWithin, which hits these GiST indexes)
CREATE INDEX idx_tuition_location ON tuition_posts USING GIST (public_location);
CREATE INDEX idx_areas_center     ON tutor_teaching_areas USING GIST (public_center);

-- Array filters (subject / class overlap with &&)
CREATE INDEX idx_tuition_subjects   ON tuition_posts USING GIN (subjects);
CREATE INDEX idx_tutorpost_subjects ON tutor_availability_posts USING GIN (subjects);
CREATE INDEX idx_tutorpost_classes  ON tutor_availability_posts USING GIN (class_levels);

-- Common active-listing scans
CREATE INDEX idx_tuition_active   ON tuition_posts (class_level, created_at DESC) WHERE status = 'active';
CREATE INDEX idx_tuition_budget   ON tuition_posts (monthly_min, monthly_max)     WHERE status = 'active';
CREATE INDEX idx_tutorpost_active ON tutor_availability_posts (created_at DESC)   WHERE status = 'active';
CREATE INDEX idx_tutorpost_budget ON tutor_availability_posts (monthly_min, monthly_max) WHERE status = 'active';

-- Keyword search
CREATE INDEX idx_tuition_title_trgm ON tuition_posts USING GIN (title gin_trgm_ops);
CREATE INDEX idx_tuition_area_trgm  ON tuition_posts USING GIN (area_name gin_trgm_ops);

-- Expiry sweep (server marks lapsed active posts as 'expired')
CREATE INDEX idx_tuition_expiry   ON tuition_posts (expires_at)            WHERE status = 'active';
CREATE INDEX idx_tutorpost_expiry ON tutor_availability_posts (expires_at) WHERE status = 'active';

-- FK helpers
CREATE INDEX idx_tuition_guardian ON tuition_posts (guardian_id);
CREATE INDEX idx_tutorpost_tutor  ON tutor_availability_posts (tutor_id);
CREATE INDEX idx_areas_post       ON tutor_teaching_areas (availability_post_id);
CREATE INDEX idx_apps_tutor       ON tuition_applications (tutor_id);

-- ───────── updated_at triggers ─────────
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION set_public_location() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.location IS DISTINCT FROM OLD.location THEN
    NEW.public_location := fuzz_point(NEW.location);
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION set_public_center() RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.center IS DISTINCT FROM OLD.center THEN
    NEW.public_center := fuzz_point(NEW.center);
  END IF;
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tuition_publoc BEFORE INSERT OR UPDATE OF location ON tuition_posts
  FOR EACH ROW EXECUTE FUNCTION set_public_location();
CREATE TRIGGER trg_area_pubctr    BEFORE INSERT OR UPDATE OF center   ON tutor_teaching_areas
  FOR EACH ROW EXECUTE FUNCTION set_public_center();

CREATE TRIGGER trg_users_upd      BEFORE UPDATE ON users                    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_tutor_prof_upd BEFORE UPDATE ON tutor_profiles           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_tuition_upd    BEFORE UPDATE ON tuition_posts            FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_tutor_post_upd BEFORE UPDATE ON tutor_availability_posts FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ═════════ Global feed: multi-language full-text search + earthdistance proximity ═════════
CREATE EXTENSION IF NOT EXISTS cube;
CREATE EXTENSION IF NOT EXISTS earthdistance;

-- earthdistance works on plain lat/lng columns. These are GENERATED FROM THE FUZZED public_location
-- (never the exact pin), so everything indexed and ranked below is safe to expose publicly.
ALTER TABLE tuition_posts
  ADD COLUMN pub_lat       DOUBLE PRECISION GENERATED ALWAYS AS (ST_Y(public_location::geometry)) STORED,
  ADD COLUMN pub_lng       DOUBLE PRECISION GENERATED ALWAYS AS (ST_X(public_location::geometry)) STORED,
  ADD COLUMN search_vector TSVECTOR;

-- Every searchable text is indexed twice and the two vectors are concatenated:
--   'english' -> stemming + stop words  ("tutoring" matches "tutor")
--   'simple'  -> no stemming, no stop words: exact lower-cased tokens in ANY language (Bangla, Hindi, Arabic, ...)
-- Weights: A title > B subjects > C class/medium/area > D description.
-- PRIVACY: formatted_address (the exact address) is deliberately NOT indexed.
CREATE OR REPLACE FUNCTION tuition_posts_search_vector_update() RETURNS TRIGGER AS $$
DECLARE
  subj TEXT := array_to_string(NEW.subjects, ' ');
  meta TEXT := concat_ws(' ', NEW.class_level, NEW.medium, NEW.area_name);
BEGIN
  NEW.search_vector :=
       setweight(to_tsvector('english', coalesce(NEW.title, '')),       'A')
    || setweight(to_tsvector('simple',  coalesce(NEW.title, '')),       'A')
    || setweight(to_tsvector('english', coalesce(subj, '')),            'B')
    || setweight(to_tsvector('simple',  coalesce(subj, '')),            'B')
    || setweight(to_tsvector('english', coalesce(meta, '')),            'C')
    || setweight(to_tsvector('simple',  coalesce(meta, '')),            'C')
    || setweight(to_tsvector('english', coalesce(NEW.description, '')), 'D')
    || setweight(to_tsvector('simple',  coalesce(NEW.description, '')), 'D');
  RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_tuition_search
  BEFORE INSERT OR UPDATE OF title, description, subjects, class_level, medium, area_name ON tuition_posts
  FOR EACH ROW EXECUTE FUNCTION tuition_posts_search_vector_update();

UPDATE tuition_posts SET title = title;                 -- back-fills search_vector for existing rows
ALTER TABLE tuition_posts ALTER COLUMN search_vector SET NOT NULL;

-- Partial indexes: only live posts are indexed, so filled/cancelled/expired history costs nothing.
-- The feed query repeats `status = 'active'` literally, which lets the planner use them.
CREATE INDEX idx_tuition_search ON tuition_posts USING GIN  (search_vector)                    WHERE status = 'active';
CREATE INDEX idx_tuition_earth  ON tuition_posts USING GIST (ll_to_earth(pub_lat, pub_lng))    WHERE status = 'active';

COMMIT;
